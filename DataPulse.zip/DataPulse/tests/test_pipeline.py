"""
Automated tests for the DataPulse data pipeline.

Run from the project root (the folder that contains app.py):

    python -m unittest discover -s tests -v

The tests use a temporary folder, so they never touch your real database.
"""
import io
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules import analytics, database as db, monitoring  # noqa: E402
from modules.data_quality import run_quality_checks, report_to_markdown, report_to_json  # noqa: E402
from modules.ingestion import (IngestionError, generate_sample_dataset, load_dataset,  # noqa: E402
                               validate_file)
from modules.transformation import TransformationError, clean_dataset  # noqa: E402


class IngestionTests(unittest.TestCase):
    def test_rejects_bad_files(self):
        with self.assertRaises(IngestionError):
            validate_file("data.txt", 10)
        with self.assertRaises(IngestionError):
            validate_file("data.csv", 0)
        with self.assertRaises(IngestionError):
            load_dataset("empty.csv", b"a,b\n")

    def test_reads_csv_with_latin1_encoding(self):
        data = "InvoiceNo,Description\n1,CAFÉ MUG\n".encode("latin-1")
        df = load_dataset("latin.csv", data)
        self.assertEqual(df.shape, (1, 2))

    def test_reads_excel(self):
        buf = io.BytesIO()
        generate_sample_dataset(n_invoices=20).to_excel(buf, index=False)
        df = load_dataset("sample.xlsx", buf.getvalue())
        self.assertIn("InvoiceNo", df.columns)
        self.assertGreater(len(df), 20)

    def test_corrupt_excel_gives_friendly_error(self):
        with self.assertRaises(IngestionError):
            load_dataset("broken.xlsx", b"this is not a real excel file")


class QualityAndCleaningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = generate_sample_dataset()
        cls.report = run_quality_checks(cls.raw)
        cls.result = clean_dataset(cls.raw)

    def test_quality_report_finds_the_planted_problems(self):
        checks = {c["Check"]: c["Count"] for c in self.report["invalid_checks"]}
        self.assertGreater(self.report["duplicates"]["count"], 0)
        self.assertGreater(checks["Unit price is negative"], 0)
        self.assertGreater(checks["Invoice date cannot be parsed"], 0)
        self.assertGreater(self.report["total_missing_cells"], 0)
        self.assertTrue(0 <= self.report["score"] <= 100)
        self.assertTrue(self.report["ready_for_etl"])

    def test_report_exports(self):
        self.assertIn(b"Data Quality Report", report_to_markdown(self.report))
        self.assertIn(b"score", report_to_json(self.report))

    def test_row_counts_add_up(self):
        s = self.result.stats
        self.assertEqual(s["rows_input"], len(self.raw))
        self.assertEqual(s["rows_clean"] + s["rows_rejected"], s["rows_input"])
        self.assertEqual(sum(s["rejection_reasons"].values()), s["rows_rejected"])

    def test_clean_data_is_actually_clean(self):
        c = self.result.clean
        self.assertFalse(c.duplicated().any())
        self.assertFalse(c.isna().any().any())
        self.assertTrue((c["UnitPrice"] > 0).all())
        self.assertTrue(pd.api.types.is_datetime64_any_dtype(c["InvoiceDate"]))
        self.assertTrue((c["Revenue"] == (c["Quantity"] * c["UnitPrice"]).round(2)).all())

    def test_returns_are_handled(self):
        c = self.result.clean
        returns = c[c["TransactionType"] == "Return"]
        self.assertGreater(len(returns), 0)
        self.assertTrue(returns["InvoiceNo"].str.startswith("C").all())
        self.assertTrue((returns["Quantity"] < 0).all())
        sales = c[c["TransactionType"] == "Sale"]
        self.assertTrue((sales["Quantity"] > 0).all())

    def test_missing_values_are_filled(self):
        c = self.result.clean
        self.assertIn("Guest", set(c["CustomerID"]))
        self.assertNotIn("UNKNOWN PRODUCT", set(c["Description"]))  # filled from StockCode
        self.assertNotIn("EIRE", set(c["Country"]))
        self.assertIn("Ireland", set(c["Country"]))

    def test_rejected_rows_have_reasons(self):
        r = self.result.rejected
        self.assertEqual(len(r), self.result.stats["rows_rejected"])
        self.assertFalse(r["RejectReason"].isna().any())

    def test_input_is_not_modified(self):
        before = self.raw.copy()
        clean_dataset(self.raw)
        pd.testing.assert_frame_equal(before, self.raw)

    def test_alternative_column_names_are_recognised(self):
        df = pd.DataFrame({"Invoice": ["1", "2"], "SKU": ["sku1", "sku2"], "Qty": [1, 2],
                           "Date": ["2024-01-05", "2024-02-10"], "Price": [2.5, 3.0],
                           "Customer ID": [1.0, None], "Country": ["UK", "Germany"]})
        res = clean_dataset(df)
        self.assertEqual(res.stats["rows_clean"], 2)
        self.assertIn("United Kingdom", set(res.clean["Country"]))
        self.assertFalse(res.stats["has_category"])

    def test_missing_required_columns(self):
        df = pd.DataFrame({"Foo": [1], "Bar": [2]})
        self.assertFalse(run_quality_checks(df)["ready_for_etl"])
        with self.assertRaises(TransformationError):
            clean_dataset(df)


class DatabaseAndAnalyticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls._tmp.name)
        cls.db_path = cls.dir / "test.db"
        cls.raw = generate_sample_dataset()
        cls.summary = monitoring.run_pipeline(cls.raw, "sample.csv", db_path=cls.db_path,
                                              processed_dir=cls.dir / "processed")
        cls.clean = clean_dataset(cls.raw).clean

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def test_pipeline_succeeds_and_records_history(self):
        self.assertEqual(self.summary["status"], "SUCCESS", self.summary.get("error"))
        self.assertEqual(len(self.summary["stages"]), 6)
        history = monitoring.get_run_history(db_path=self.db_path)
        self.assertEqual(len(history), 1)
        self.assertEqual(history.iloc[0]["status"], "SUCCESS")
        details = monitoring.get_run_details(int(history.iloc[0]["run_id"]), self.db_path)
        self.assertIn("quality_report", details["details"])
        self.assertIsNotNone(monitoring.get_latest_quality_report(self.db_path))
        self.assertTrue((self.dir / "processed" / monitoring.CLEAN_EXPORT_NAME).exists())

    def test_tables_hold_the_right_rows(self):
        with db.readonly(self.db_path) as conn:
            self.assertEqual(db.count_rows(conn, db.TABLE_RAW), len(self.raw))
            self.assertEqual(db.count_rows(conn, db.TABLE_CLEAN), self.summary["rows_clean"])
            self.assertEqual(db.count_rows(conn, db.TABLE_REJECTED), self.summary["rows_rejected"])

    def test_kpis_match_pandas(self):
        k = analytics.get_kpis(db_path=self.db_path)
        sales = self.clean[self.clean["TransactionType"] == "Sale"]
        returns = self.clean[self.clean["TransactionType"] == "Return"]
        self.assertAlmostEqual(k["total_revenue"], sales["Revenue"].sum(), places=1)
        self.assertAlmostEqual(k["returns_value"], -returns["Revenue"].sum(), places=1)
        self.assertEqual(k["total_orders"], sales["InvoiceNo"].nunique())
        self.assertEqual(k["units_sold"], int(sales["Quantity"].sum()))
        self.assertAlmostEqual(k["net_revenue"], k["total_revenue"] - k["returns_value"], places=1)

    def test_analytics_tables(self):
        monthly = analytics.get_monthly_revenue(db_path=self.db_path)
        self.assertAlmostEqual(monthly["Revenue"].sum(), analytics.get_kpis(db_path=self.db_path)["total_revenue"], places=0)
        self.assertEqual(len(analytics.get_top_products("Units", 5, db_path=self.db_path)), 5)
        self.assertGreater(len(analytics.get_country_sales(db_path=self.db_path)), 1)
        self.assertGreater(len(analytics.get_category_performance(db_path=self.db_path)), 1)
        self.assertEqual(len(analytics.get_weekday_sales(db_path=self.db_path)), 7)
        self.assertGreater(len(analytics.get_top_returns(db_path=self.db_path)), 0)

    def test_filters_work(self):
        opts = analytics.get_filter_options(self.db_path)
        all_k = analytics.get_kpis(db_path=self.db_path)
        uk = analytics.get_kpis({"countries": ["United Kingdom"]}, self.db_path)
        self.assertLess(uk["total_revenue"], all_k["total_revenue"])
        none = analytics.get_kpis({"start": "2099-01-01"}, self.db_path)
        self.assertEqual(none["total_orders"], 0)
        self.assertIn("United Kingdom", opts["countries"])

    def test_reports(self):
        k = analytics.get_kpis(db_path=self.db_path)
        m = analytics.get_monthly_revenue(db_path=self.db_path)
        p = analytics.get_top_products(db_path=self.db_path)
        c = analytics.get_country_sales(db_path=self.db_path)
        cat = analytics.get_category_performance(db_path=self.db_path)
        self.assertIn(b"Analytics Summary", analytics.build_analytics_summary_md(k, m, p, c, cat))
        xlsx = analytics.build_analytics_excel(k, m, p, c, cat)
        sheets = pd.ExcelFile(io.BytesIO(xlsx)).sheet_names
        self.assertIn("KPIs", sheets)
        self.assertIn("Categories", sheets)
        self.assertGreater(len(analytics.dataframe_to_excel_bytes(self.clean.head(50))), 1000)
        with self.assertRaises(analytics.AnalyticsError):
            analytics.dataframe_to_excel_bytes(pd.DataFrame({"a": range(analytics.EXCEL_EXPORT_MAX_ROWS + 1)}))

    def test_sql_playground_is_read_only(self):
        ok = db.run_select_query("SELECT COUNT(*) AS n FROM clean_data;", self.db_path)
        self.assertGreater(int(ok.loc[0, "n"]), 0)
        for name, sql in db.SAMPLE_QUERIES.items():
            db.run_select_query(sql, self.db_path)  # every bundled example must run
        for bad in ["DROP TABLE clean_data", "DELETE FROM clean_data", "SELECT 1; DROP TABLE clean_data",
                    "UPDATE clean_data SET Revenue = 0", "PRAGMA table_info(clean_data)", "", "   "]:
            with self.assertRaises(db.DatabaseError, msg=bad):
                db.run_select_query(bad, self.db_path)
        with self.assertRaises(db.DatabaseError):
            db.run_select_query("SELECT * FROM table_that_does_not_exist", self.db_path)
        with db.readonly(self.db_path) as conn:  # data still intact after the attack attempts
            self.assertGreater(db.count_rows(conn, db.TABLE_CLEAN), 0)

    def test_table_browser(self):
        self.assertEqual(len(db.read_table(db.TABLE_CLEAN, limit=5, db_path=self.db_path)), 5)
        self.assertIn("Revenue", db.get_table_schema(db.TABLE_CLEAN, self.db_path)["Column"].tolist())
        with self.assertRaises(db.DatabaseError):
            db.read_table("sqlite_master", db_path=self.db_path)
        info = db.get_database_info(self.db_path)
        self.assertEqual({t["Table"] for t in info["tables"]}, set(db.ALL_TABLES))


class PipelineFailureTests(unittest.TestCase):
    def test_bad_data_fails_gracefully_and_is_logged(self):
        with tempfile.TemporaryDirectory() as tmp:
            dbp = Path(tmp) / "t.db"
            summary = monitoring.run_pipeline(pd.DataFrame({"x": [1, 2]}), "bad.csv", db_path=dbp,
                                              processed_dir=Path(tmp) / "p")
            self.assertEqual(summary["status"], "FAILED")
            self.assertIn("Required column", summary["error"])
            history = monitoring.get_run_history(db_path=dbp)
            self.assertEqual(history.iloc[0]["status"], "FAILED")
            self.assertEqual(monitoring.get_latest_successful_run_id(dbp), 0)

    def test_everything_rejected_fails_gracefully(self):
        df = pd.DataFrame({"InvoiceNo": ["1"], "StockCode": ["A"], "Quantity": [1],
                           "InvoiceDate": ["2024-01-01"], "UnitPrice": [0.0]})
        with tempfile.TemporaryDirectory() as tmp:
            summary = monitoring.run_pipeline(df, "zero.csv", db_path=Path(tmp) / "t.db",
                                              processed_dir=Path(tmp) / "p")
            self.assertEqual(summary["status"], "FAILED")

    def test_analytics_before_pipeline_gives_clear_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(analytics.AnalyticsError):
                analytics.get_kpis(db_path=Path(tmp) / "nothing.db")


@unittest.skipIf(getattr(analytics.go, "__stub__", False), "real Plotly not installed")
class ChartTests(unittest.TestCase):
    def test_every_chart_builds(self):
        month = pd.DataFrame({"Month": ["2011-01", "2011-02"], "Revenue": [10.0, 20.0],
                              "Returns": [1.0, 2.0], "Orders": [1, 2]})
        prod = pd.DataFrame({"StockCode": ["A", "B"], "Description": ["Alpha", "Beta"],
                             "Units": [5, 3], "Revenue": [50.0, 30.0]})
        ctry = pd.DataFrame({"Country": ["UK", "DE"], "Revenue": [80.0, 20.0], "Orders": [4, 1], "Units": [9, 2]})
        cat = pd.DataFrame({"Category": ["X", "Y"], "Revenue": [60.0, 40.0], "Orders": [3, 2], "Units": [7, 4]})
        day = pd.DataFrame({"Day": ["Mon", "Tue"], "Revenue": [1.0, 2.0], "Orders": [1, 1]})
        runs = pd.DataFrame({"run_id": [1, 2], "rows_clean": [10, 20], "rows_rejected": [1, 2]})
        figs = [analytics.fig_monthly_revenue(month), analytics.fig_top_products(prod, "Revenue"),
                analytics.fig_top_products(prod, "Units"), analytics.fig_country_sales(ctry),
                analytics.fig_category(cat), analytics.fig_weekday(day), analytics.fig_quality_gauge(88.5),
                analytics.fig_dimension_scores({"A": 90.0, "B": 80.0}),
                analytics.fig_rejection_reasons({"Zero UnitPrice": 3, "Duplicate record": 5}),
                analytics.fig_run_history(runs)]
        for fig in figs:
            self.assertIsInstance(fig, analytics.go.Figure)
            fig.to_dict()


if __name__ == "__main__":
    unittest.main(verbosity=2)
