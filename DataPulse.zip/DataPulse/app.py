"""
DataPulse - Smart Retail Data Pipeline & Analytics Platform
===========================================================
Streamlit user interface. All data logic lives in the modules/ package;
this file only handles layout, user input and display.

Run locally / in Codespaces:   streamlit run app.py
"""
from __future__ import annotations

import base64
import html
import traceback
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from modules import analytics, database as db, monitoring
from modules.data_quality import (report_to_csv, report_to_json, report_to_markdown,
                                  run_quality_checks)
from modules.ingestion import (REQUIRED_COLUMNS, IngestionError, detect_columns,
                               get_column_summary, get_dataset_overview, load_dataset,
                               load_sample_dataset, map_columns, save_raw_copy)

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
CUR = analytics.CURRENCY

st.set_page_config(page_title="DataPulse", page_icon="📊", layout="wide",
                   initial_sidebar_state="auto")

PAGES = {
    "📥 Data Ingestion": "ingestion",
    "🔍 Data Quality": "quality",
    "⚙️ ETL Pipeline": "etl",
    "🗄️ Database": "database",
    "📈 Analytics Dashboard": "analytics",
    "🛰️ Pipeline Monitoring": "monitoring",
    "📄 Reports": "reports",
}

for _key, _default in {"df": None, "file_name": None, "last_upload_id": None,
                       "quality_report": None, "last_run": None}.items():
    st.session_state.setdefault(_key, _default)


# ==========================================================================
# Small UI helpers
# ==========================================================================
def load_css() -> None:
    try:
        css = (ASSETS / "style.css").read_text(encoding="utf-8")
        st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)
    except OSError:
        pass  # the app still works with Streamlit's default look


def logo_html() -> str:
    try:
        b64 = base64.b64encode((ASSETS / "logo.svg").read_bytes()).decode()
        return f'<img src="data:image/svg+xml;base64,{b64}" alt="DataPulse logo"/>'
    except OSError:
        return "📊"


def hero(title: str, subtitle: str) -> None:
    st.markdown(f'<div class="hero"><div class="hero-title">{html.escape(title)}</div>'
                f'<div class="hero-sub">{html.escape(subtitle)}</div></div>', unsafe_allow_html=True)


def section(title: str) -> None:
    st.markdown(f'<div class="section-title">{html.escape(title)}</div>', unsafe_allow_html=True)


def kpi_grid(items: list[dict]) -> None:
    """Responsive grid of rounded KPI cards. Each item: label, value, sub (optional), tone (optional)."""
    cards = "".join(
        f'<div class="kpi-card {html.escape(i.get("tone", ""))}">'
        f'<div class="kpi-label">{html.escape(str(i["label"]))}</div>'
        f'<div class="kpi-value">{html.escape(str(i["value"]))}</div>'
        f'<div class="kpi-sub">{html.escape(str(i.get("sub", "")))}</div></div>' for i in items)
    st.markdown(f'<div class="kpi-grid">{cards}</div>', unsafe_allow_html=True)


def money(v: float) -> str:
    sign, a = ("-" if v < 0 else ""), abs(v)
    if a >= 1e6:
        return f"{sign}{CUR}{a / 1e6:,.2f}M"
    if a >= 1e4:
        return f"{sign}{CUR}{a / 1e3:,.1f}K"
    return f"{sign}{CUR}{a:,.2f}"


def count(n: int) -> str:
    return f"{n / 1e6:,.2f}M" if n >= 1e6 else f"{n:,}"


def show_chart(fig, key: str) -> None:
    st.plotly_chart(fig, key=key, theme=None, config={"displayModeBar": False, "responsive": True})


def show_table(df: pd.DataFrame) -> None:
    st.dataframe(df, hide_index=True)


def badge(status: str) -> str:
    css = {"SUCCESS": "ok", "FAILED": "fail"}.get(status, "run")
    return f'<span class="badge {css}">{html.escape(status)}</span>'


def need_dataset() -> bool:
    if st.session_state["df"] is None:
        st.info("No dataset loaded yet. Open **📥 Data Ingestion** in the sidebar and upload a file "
                "(or click *Load demo dataset*).")
        return False
    return True


def need_clean_data() -> bool:
    if not db.clean_data_ready():
        st.info("No cleaned data in the database yet. Load a dataset, then run the "
                "**⚙️ ETL Pipeline** from the sidebar.")
        return False
    return True


def data_token() -> int:
    """Changes every time a new pipeline run succeeds; used to refresh cached results."""
    try:
        return monitoring.get_latest_successful_run_id()
    except Exception:
        return 0


# ==========================================================================
# Cached database reads (refresh automatically when `token` changes)
# ==========================================================================
@st.cache_data(show_spinner=False)
def cached_filter_options(token: int) -> dict:
    return analytics.get_filter_options()


@st.cache_data(show_spinner="Running SQL queries on SQLite...")
def cached_analytics(token: int, start: str, end: str, countries: tuple, metric: str, top_n: int) -> dict:
    f = {"start": start, "end": end, "countries": list(countries)}
    return {
        "kpis": analytics.get_kpis(f),
        "monthly": analytics.get_monthly_revenue(f),
        "products": analytics.get_top_products(metric, top_n, f),
        "countries": analytics.get_country_sales(f),
        "categories": analytics.get_category_performance(f),
        "weekday": analytics.get_weekday_sales(f),
        "returns": analytics.get_top_returns(8, f),
    }


@st.cache_data(show_spinner="Preparing cleaned data...")
def cached_table_csv(token: int, table: str) -> bytes:
    df = db.read_full_table(table)
    return analytics.dataframe_to_csv_bytes(df.drop(columns=["id"], errors="ignore"))


# ==========================================================================
# Pages
# ==========================================================================
def page_ingestion() -> None:
    hero("Data Ingestion", "Upload a retail dataset (CSV or Excel), then preview its structure.")

    uploaded = st.file_uploader("Choose a CSV or Excel (.xlsx) file", type=["csv", "xlsx"])
    st.caption("Tip: the full UCI Online Retail Excel file (~23 MB, 541k rows) can take 1-2 minutes to read. "
               "Converting it to CSV first makes it much faster (see README).")

    if uploaded is not None:
        upload_id = f"{uploaded.name}-{uploaded.size}"
        if st.session_state["last_upload_id"] != upload_id:  # only read NEW uploads
            try:
                data = uploaded.getvalue()
                with st.spinner("Reading file..."):
                    df = load_dataset(uploaded.name, data)
                try:
                    saved = save_raw_copy(uploaded.name, data)
                    st.success(f"Loaded '{uploaded.name}'. A raw copy was saved as {saved.name}.")
                except OSError:
                    st.success(f"Loaded '{uploaded.name}'.")
                    st.warning("Could not save a raw copy to disk (read-only hosting?). The data is still loaded.")
                st.session_state.update(df=df, file_name=uploaded.name, last_upload_id=upload_id,
                                        quality_report=None, last_run=None)
            except IngestionError as err:
                st.error(str(err))
                return
            except Exception as err:  # last safety net so the app never crashes
                st.error(f"Unexpected error while reading the file: {err}")
                return

    if st.button("Load demo dataset (small sample with built-in data problems)"):
        try:
            st.session_state.update(df=load_sample_dataset(), file_name="sample_retail_data.csv",
                                    quality_report=None, last_run=None)
            st.success("Demo dataset loaded.")
        except Exception as err:
            st.error(f"Could not load the demo dataset: {err}")
            return

    df = st.session_state["df"]
    if df is None:
        st.markdown('<div class="note"><b>Getting started:</b> 1) upload a file or load the demo data &rarr; '
                    '2) check data quality &rarr; 3) run the ETL pipeline &rarr; 4) explore the dashboard.</div>',
                    unsafe_allow_html=True)
        return

    st.markdown(f"**Current dataset:** `{st.session_state['file_name']}`")
    ov = get_dataset_overview(df)
    kpi_grid([
        {"label": "Rows", "value": f"{ov['rows']:,}"},
        {"label": "Columns", "value": ov["columns"], "tone": "alt"},
        {"label": "Memory", "value": f"{ov['memory_mb']} MB"},
        {"label": "Missing cells", "value": f"{ov['missing_pct']}%", "sub": f"{ov['missing_cells']:,} cells",
         "tone": "alt"},
    ])

    section("Dataset preview")
    n = st.slider("Rows to preview", 5, 100, 10)
    show_table(df.head(n))

    section("Columns and data types")
    show_table(get_column_summary(df))

    with st.expander("How DataPulse understands your columns"):
        mapping = detect_columns(df)
        _, _, missing = map_columns(df)
        if mapping:
            show_table(pd.DataFrame({"Your column": list(mapping.keys()), "DataPulse field": list(mapping.values())}))
        if missing:
            st.error("Required columns not found: " + ", ".join(missing)
                     + ". Rename your columns (e.g. InvoiceNo, StockCode, Quantity, InvoiceDate, UnitPrice).")
        else:
            st.success("All required columns found: " + ", ".join(REQUIRED_COLUMNS))


def render_quality_report(report: dict, key_prefix: str) -> None:
    c1, c2 = st.columns([1, 1])
    with c1:
        show_chart(analytics.fig_quality_gauge(report["score"]), f"{key_prefix}_gauge")
        st.markdown(f"<div style='text-align:center'><b>Grade: {html.escape(report['grade'])}</b></div>",
                    unsafe_allow_html=True)
    with c2:
        show_chart(analytics.fig_dimension_scores(report["dimension_scores"]), f"{key_prefix}_dims")

    kpi_grid([
        {"label": "Rows checked", "value": f"{report['rows']:,}"},
        {"label": "Missing cells", "value": f"{report['total_missing_cells']:,}", "tone": "alt"},
        {"label": "Duplicate rows", "value": f"{report['duplicates']['count']:,}",
         "sub": f"{report['duplicates']['pct']}% of rows"},
        {"label": "Rows with invalid values", "value": f"{report['invalid_rows']:,}", "tone": "alt"},
    ])

    t1, t2, t3, t4, t5 = st.tabs(["Missing values", "Duplicates", "Invalid values", "Data types", "Recommendations"])
    with t1:
        show_table(pd.DataFrame(report["missing_values"]))
    with t2:
        d = report["duplicates"]
        st.metric("Exact duplicate rows", f"{d['count']:,}", f"{d['pct']}% of all rows", delta_color="off")
        st.caption("Duplicates are identical across every column. The ETL step keeps the first copy.")
    with t3:
        show_table(pd.DataFrame(report["invalid_checks"]))
        st.caption("'info' rows (cancelled invoices) are valid business data and do not reduce the score.")
    with t4:
        show_table(pd.DataFrame(report["data_types"]))
    with t5:
        for rec in report["recommendations"]:
            st.markdown(f"- {rec}")


def page_quality() -> None:
    hero("Data Quality Checker", "Find missing values, duplicates, invalid values and wrong data types.")
    if not need_dataset():
        return

    if st.button("Run quality check", type="primary"):
        try:
            with st.spinner("Checking data quality..."):
                st.session_state["quality_report"] = run_quality_checks(st.session_state["df"])
        except Exception as err:
            st.error(f"Quality check failed: {err}")
            return

    report = st.session_state["quality_report"]
    if report is None:
        st.info("Click **Run quality check** to analyse the loaded dataset.")
        return

    if not report["ready_for_etl"]:
        st.error("Required columns missing: " + ", ".join(report["missing_required"])
                 + ". The ETL pipeline cannot run until these are present.")
    render_quality_report(report, "q")

    section("Download this report")
    c1, c2, c3 = st.columns(3)
    c1.download_button("Markdown report", report_to_markdown(report), "data_quality_report.md",
                       "text/markdown", key="q_md")
    c2.download_button("JSON report", report_to_json(report), "data_quality_report.json",
                       "application/json", key="q_json")
    c3.download_button("Issues table (CSV)", report_to_csv(report), "data_quality_issues.csv",
                       "text/csv", key="q_csv")


def render_run_summary(summary: dict, key_prefix: str) -> None:
    ok = summary["status"] == "SUCCESS"
    st.markdown(f"**Run #{summary.get('run_id')}** &nbsp; {badge(summary['status'])} &nbsp; "
                f"`{summary['source_file']}` &nbsp; · {summary['duration_sec']}s", unsafe_allow_html=True)
    if not ok:
        st.error(f"Pipeline failed: {summary.get('error')}")
    kpi_grid([
        {"label": "Records in", "value": f"{summary['rows_input']:,}"},
        {"label": "Clean records", "value": f"{summary['rows_clean']:,}", "tone": "good" if ok else "bad"},
        {"label": "Rejected", "value": f"{summary['rows_rejected']:,}", "tone": "alt"},
        {"label": "Duplicates removed", "value": f"{summary['duplicates_removed']:,}", "tone": "alt"},
        {"label": "Quality score", "value": "-" if summary.get("quality_score") is None
         else f"{summary['quality_score']}", "sub": summary.get("quality_grade") or ""},
    ])
    section("Stage-by-stage status")
    show_table(pd.DataFrame(summary["stages"]))
    if summary.get("steps"):
        section("What the transformation did")
        for s in summary["steps"]:
            st.markdown(f"- **{s['step']}:** {s['detail']}")
    if summary.get("rejection_reasons"):
        show_chart(analytics.fig_rejection_reasons(summary["rejection_reasons"]), f"{key_prefix}_reasons")


def page_etl() -> None:
    hero("ETL Pipeline", "Extract, transform and load the uploaded data into SQLite.")
    with st.expander("What happens when you run the pipeline?"):
        st.markdown(
            "1. **Extract** - read the loaded dataset and check required columns\n"
            "2. **Quality check** - score the raw data\n"
            "3. **Transform** - standardise formats, reject invalid rows, remove duplicates, fill missing values, "
            "keep cancelled invoices as *Return* lines\n"
            "4. **Load raw** - store the untouched data in `raw_data`\n"
            "5. **Load clean** - store cleaned rows in `clean_data` and rejected rows in `rejected_data`\n"
            "6. **Export** - save CSV copies to `data/processed/`")
    if not need_dataset():
        return

    st.markdown(f"Dataset: `{st.session_state['file_name']}` · {len(st.session_state['df']):,} rows")
    st.caption("Running the pipeline replaces the previous raw/clean/rejected tables. Run history is kept.")

    if st.button("Run ETL pipeline", type="primary"):
        bar = st.progress(0.0, text="Starting pipeline...")

        def on_progress(fraction: float, message: str) -> None:
            bar.progress(min(max(fraction, 0.0), 1.0), text=message)

        summary = monitoring.run_pipeline(st.session_state["df"], st.session_state["file_name"] or "dataset",
                                          progress_callback=on_progress)
        bar.empty()
        st.session_state["last_run"] = summary
        if summary["status"] == "SUCCESS":
            st.session_state["quality_report"] = summary["details"]["quality_report"]
            st.success("Pipeline finished. Open **📈 Analytics Dashboard** from the sidebar to explore the results.")

    if st.session_state["last_run"]:
        render_run_summary(st.session_state["last_run"], "etl")


def page_database() -> None:
    hero("Database Management", "Inspect the SQLite tables and run your own SQL queries.")
    info = db.get_database_info()
    if not info["exists"] or not info["tables"]:
        st.info("The database is empty. Run the **⚙️ ETL Pipeline** first.")
        return

    kpi_grid([{"label": "Database file", "value": f"{info['size_mb']} MB", "sub": "database/datapulse.db"}]
             + [{"label": t["Table"], "value": f"{t['Rows']:,}", "sub": "rows", "tone": "alt"}
                for t in info["tables"]])

    tab1, tab2, tab3 = st.tabs(["Browse tables", "SQL playground", "Maintenance"])

    with tab1:
        names = [t["Table"] for t in info["tables"]]
        table = st.selectbox("Table", names, index=names.index(db.TABLE_CLEAN) if db.TABLE_CLEAN in names else 0)
        rows = st.slider("Rows to show", 5, 500, 50, key="db_rows")
        try:
            with st.expander("Table structure (schema)"):
                show_table(db.get_table_schema(table))
            show_table(db.read_table(table, limit=rows))
        except db.DatabaseError as err:
            st.error(str(err))

    with tab2:
        st.caption("Write a SELECT query. The connection is read-only, so nothing can be changed or deleted. "
                   f"At most {db.MAX_QUERY_ROWS:,} rows are returned.")
        choice = st.selectbox("Start from an example", list(db.SAMPLE_QUERIES.keys()))
        sql = st.text_area("SQL query", value=db.SAMPLE_QUERIES[choice], height=190, key=f"sql_{choice}")
        if st.button("Run query", type="primary"):
            try:
                result = db.run_select_query(sql)
                st.success(f"{len(result):,} row(s) returned.")
                show_table(result)
                st.download_button("Download result (CSV)", analytics.dataframe_to_csv_bytes(result),
                                   "query_result.csv", "text/csv", key="sql_dl")
            except db.DatabaseError as err:
                st.error(str(err))

    with tab3:
        st.warning("Resetting deletes the raw, clean and rejected tables. You will need to re-run the pipeline.")
        sure = st.checkbox("I understand - delete the data tables")
        keep = st.checkbox("Keep pipeline run history", value=True)
        if st.button("Reset database", disabled=not sure):
            try:
                db.reset_database(keep_history=keep)
                st.session_state["last_run"] = None
                st.cache_data.clear()
                st.success("Database reset.")
                st.rerun()
            except db.DatabaseError as err:
                st.error(str(err))


def page_analytics() -> None:
    hero("Retail Analytics Dashboard", "Revenue, orders, products and countries at a glance.")
    if not need_clean_data():
        return
    token = data_token()

    try:
        opts = cached_filter_options(token)
        with st.expander("Filters", expanded=False):
            lo, hi = date.fromisoformat(opts["min_date"]), date.fromisoformat(opts["max_date"])
            picked = st.date_input("Date range", value=(lo, hi), min_value=lo, max_value=hi,
                                   key=f"dates_{token}")
            if isinstance(picked, (tuple, list)) and len(picked) == 2:
                start, end = picked
            else:
                start, end = lo, hi
                st.caption("Pick an end date to apply the range.")
            countries = st.multiselect("Countries (empty = all)", opts["countries"], key=f"ctry_{token}")
            c1, c2 = st.columns(2)
            metric = c1.radio("Rank products by", ["Revenue", "Units"], horizontal=True, key=f"metric_{token}")
            top_n = c2.slider("Products to show", 5, 20, 10, key=f"topn_{token}")

        data = cached_analytics(token, str(start), str(end), tuple(countries), metric, top_n)
    except analytics.AnalyticsError as err:
        st.error(str(err))
        return

    k = data["kpis"]
    kpi_grid([
        {"label": "Total revenue", "value": money(k["total_revenue"]), "sub": "gross sales, excl. returns"},
        {"label": "Total orders", "value": count(k["total_orders"]), "sub": "distinct invoices", "tone": "alt"},
        {"label": "Products sold", "value": count(k["units_sold"]), "sub": "units"},
        {"label": "Avg order value", "value": money(k["avg_order_value"]), "sub": "revenue / orders", "tone": "alt"},
    ])
    kpi_grid([
        {"label": "Net revenue", "value": money(k["net_revenue"]), "sub": "after returns", "tone": "good"},
        {"label": "Returns value", "value": money(k["returns_value"]),
         "sub": f"{k['return_rate_pct']}% of revenue", "tone": "bad"},
        {"label": "Customers", "value": count(k["customers"]), "sub": "excluding guests", "tone": "alt"},
        {"label": "Units returned", "value": count(k["units_returned"]), "sub": f"{k['return_orders']:,} cancelled invoices"},
    ])

    if data["monthly"].empty:
        st.warning("No sales match the selected filters.")
        return

    show_chart(analytics.fig_monthly_revenue(data["monthly"]), "an_monthly")

    c1, c2 = st.columns(2)
    with c1:
        show_chart(analytics.fig_top_products(data["products"], metric), "an_products")
    with c2:
        d = data["countries"]
        if len(d) > 1 and d.iloc[0]["Country"] == "United Kingdom" and st.checkbox(
                "Hide United Kingdom (see other markets)", key=f"hideuk_{token}"):
            d = d.iloc[1:]
        show_chart(analytics.fig_country_sales(d), "an_country")

    c3, c4 = st.columns(2)
    with c3:
        if not data["categories"].empty:
            show_chart(analytics.fig_category(data["categories"]), "an_category")
        else:
            st.info("Category-wise performance appears when your dataset has a Category column "
                    "(the UCI Online Retail data does not include one; the demo dataset does).")
    with c4:
        show_chart(analytics.fig_weekday(data["weekday"]), "an_weekday")

    with st.expander("Most returned products"):
        show_table(data["returns"])
    with st.expander("Data tables behind the charts"):
        show_table(data["monthly"])
        show_table(data["products"])
        show_table(data["countries"])


def page_monitoring() -> None:
    hero("Pipeline Monitoring", "Execution status, records processed and run history.")
    history = monitoring.get_run_history(limit=100)
    if history.empty:
        st.info("No pipeline runs yet. Run the **⚙️ ETL Pipeline** first.")
        return

    latest = history.iloc[0]
    st.markdown(f"**Latest run #{int(latest['run_id'])}** &nbsp; {badge(latest['status'])} &nbsp; "
                f"`{latest['source_file']}` · started {latest['started_at']}", unsafe_allow_html=True)
    kpi_grid([
        {"label": "Records processed", "value": f"{int(latest['rows_input'] or 0):,}"},
        {"label": "Clean", "value": f"{int(latest['rows_clean'] or 0):,}", "tone": "good"},
        {"label": "Rejected", "value": f"{int(latest['rows_rejected'] or 0):,}", "tone": "bad"},
        {"label": "Duration", "value": f"{latest['duration_sec'] or 0}s", "tone": "alt"},
        {"label": "Total runs", "value": len(history), "sub": f"{(history['status'] == 'SUCCESS').sum()} successful"},
    ])

    tab1, tab2 = st.tabs(["Execution history", "Run details"])
    with tab1:
        show_table(history.drop(columns=["error_message"]).rename(columns={
            "run_id": "Run", "source_file": "Source", "status": "Status", "started_at": "Started",
            "finished_at": "Finished", "duration_sec": "Seconds", "rows_input": "Rows in",
            "rows_clean": "Clean", "rows_rejected": "Rejected", "duplicates_removed": "Duplicates",
            "quality_score": "Quality"}))
        done = history.dropna(subset=["rows_clean"])
        if len(done) >= 1:
            show_chart(analytics.fig_run_history(done), "mon_history")
        with st.expander("Clear run history"):
            sure = st.checkbox("Yes, delete the execution history")
            if st.button("Clear history", disabled=not sure):
                monitoring.clear_run_history()
                st.cache_data.clear()
                st.rerun()

    with tab2:
        run_id = st.selectbox("Choose a run", history["run_id"].tolist(),
                              format_func=lambda r: f"Run #{r} - {history.loc[history['run_id'] == r, 'started_at'].iloc[0]}")
        details = monitoring.get_run_details(int(run_id))
        if details:
            det = details.get("details", {})
            summary = {
                "run_id": details["run_id"], "status": details["status"], "source_file": details["source_file"],
                "duration_sec": details["duration_sec"] or 0, "rows_input": details["rows_input"] or 0,
                "rows_clean": details["rows_clean"] or 0, "rows_rejected": details["rows_rejected"] or 0,
                "duplicates_removed": details["duplicates_removed"] or 0, "quality_score": details["quality_score"],
                "quality_grade": det.get("quality_grade"), "stages": det.get("stages", []),
                "steps": det.get("steps", []), "rejection_reasons": det.get("rejection_reasons", {}),
                "error": details.get("error_message"),
            }
            render_run_summary(summary, f"mon_{run_id}")


def page_reports() -> None:
    hero("Report Generation", "Download cleaned data, quality reports and analytics summaries.")
    if not need_clean_data():
        return
    token = data_token()

    section("1. Cleaned dataset")
    with db.readonly() as conn:
        n_clean, n_rej = db.count_rows(conn, db.TABLE_CLEAN), db.count_rows(conn, db.TABLE_REJECTED)
    st.caption(f"{n_clean:,} clean rows · {n_rej:,} rejected rows")
    c1, c2 = st.columns(2)
    try:
        c1.download_button("Cleaned data (CSV)", cached_table_csv(token, db.TABLE_CLEAN),
                           "datapulse_clean_data.csv", "text/csv", key="r_clean_csv")
        if n_rej:
            c2.download_button("Rejected records (CSV)", cached_table_csv(token, db.TABLE_REJECTED),
                               "datapulse_rejected_records.csv", "text/csv", key="r_rej_csv")
    except db.DatabaseError as err:
        st.error(str(err))

    if n_clean <= analytics.EXCEL_EXPORT_MAX_ROWS:
        if st.button("Prepare Excel version of cleaned data"):
            with st.spinner("Building Excel file..."):
                df = db.read_full_table(db.TABLE_CLEAN).drop(columns=["id"], errors="ignore")
                st.session_state["xlsx_clean"] = (token, analytics.dataframe_to_excel_bytes(df, "Clean data"))
        ready = st.session_state.get("xlsx_clean")
        if ready and ready[0] == token:
            st.download_button("Download cleaned data (Excel)", ready[1], "datapulse_clean_data.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key="r_xlsx")
    else:
        st.info(f"Excel export is limited to {analytics.EXCEL_EXPORT_MAX_ROWS:,} rows; "
                "use the CSV download for this larger dataset.")

    section("2. Data quality report")
    report = st.session_state.get("quality_report") or monitoring.get_latest_quality_report()
    if report:
        st.caption(f"Score {report['score']}/100 ({report['grade']}) · generated {report['generated_at']}")
        a, b, c = st.columns(3)
        a.download_button("Markdown report", report_to_markdown(report), "data_quality_report.md",
                          "text/markdown", key="r_q_md")
        b.download_button("JSON report", report_to_json(report), "data_quality_report.json",
                          "application/json", key="r_q_json")
        c.download_button("Issues table (CSV)", report_to_csv(report), "data_quality_issues.csv",
                          "text/csv", key="r_q_csv")
    else:
        st.info("No quality report yet. Run the quality check or the ETL pipeline.")

    section("3. Analytics summary")
    try:
        d = cached_analytics(token, "", "", (), "Revenue", 10)
        summary_md = analytics.build_analytics_summary_md(d["kpis"], d["monthly"], d["products"],
                                                          d["countries"], d["categories"])
        xlsx = analytics.build_analytics_excel(d["kpis"], d["monthly"], d["products"],
                                               d["countries"], d["categories"])
        a, b = st.columns(2)
        a.download_button("Analytics summary (Markdown)", summary_md, "datapulse_analytics_summary.md",
                          "text/markdown", key="r_a_md")
        b.download_button("Analytics workbook (Excel)", xlsx, "datapulse_analytics.xlsx",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key="r_a_xlsx")
        with st.expander("Preview summary"):
            st.markdown(summary_md.decode("utf-8"))
    except analytics.AnalyticsError as err:
        st.error(str(err))


# ==========================================================================
# Layout: sidebar + page router
# ==========================================================================
def sidebar() -> str:
    with st.sidebar:
        st.markdown(f'<div class="brand">{logo_html()}<div><div class="name">DataPulse</div>'
                    '<div class="tag">Smart Retail Data Pipeline</div></div></div>', unsafe_allow_html=True)
        st.divider()
        label = st.radio("Navigation", list(PAGES.keys()), label_visibility="collapsed")
        st.divider()
        df, name = st.session_state["df"], st.session_state["file_name"]
        ds = f"<b>Dataset:</b> {html.escape(name)}<br>{len(df):,} rows" if df is not None else "<b>Dataset:</b> none loaded"
        try:
            runs = monitoring.get_run_history(limit=1)
        except Exception:
            runs = pd.DataFrame()
        pipe = (f"<b>Last run:</b> #{int(runs.iloc[0]['run_id'])} {html.escape(str(runs.iloc[0]['status']))}"
                if not runs.empty else "<b>Last run:</b> none yet")
        st.markdown(f'<div class="side-status">{ds}<br>{pipe}</div>', unsafe_allow_html=True)
    return PAGES[label]


def main() -> None:
    load_css()
    page = sidebar()
    handlers = {"ingestion": page_ingestion, "quality": page_quality, "etl": page_etl,
                "database": page_database, "analytics": page_analytics,
                "monitoring": page_monitoring, "reports": page_reports}
    try:
        handlers[page]()
    except Exception as err:  # never show a raw crash screen to the user
        st.error(f"Something went wrong: {err}")
        with st.expander("Technical details"):
            st.code(traceback.format_exc())


main()
