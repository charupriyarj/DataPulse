# 📊 DataPulse – Smart Retail Data Pipeline & Analytics Platform

DataPulse turns raw retail transaction files into clean, structured data and business insights.
Upload a CSV or Excel file, check its quality, run an automated ETL pipeline into SQLite, and explore
an interactive dashboard – all from a mobile-friendly Streamlit app.

**Tech stack:** Python · Pandas · NumPy · SQLite / SQL · Streamlit · Plotly · OpenPyXL (all free)

---

## ✨ Features

| Module | What it does |
|---|---|
| **1. Data Ingestion** | Upload CSV / Excel (.xlsx), validate the file, preview rows, show row count, column count and data types |
| **2. Data Quality Checker** | Detects missing values, duplicate rows, invalid values and wrong data types; produces a 0–100 quality score and recommendations |
| **3. ETL Pipeline** | Cleans and standardises data, rejects untrustworthy rows (with reasons), removes duplicates, fills missing values, handles cancelled orders / returns, loads into SQLite |
| **4. Database Management** | Separate `raw_data`, `clean_data`, `rejected_data` tables, table browser, safe read-only **SQL playground** |
| **5. Analytics Dashboard** | KPI cards (revenue, orders, products sold, average order value, returns, customers), monthly trend, top products, sales by country, category performance (if a Category column exists), day-of-week pattern, filters |
| **6. Pipeline Monitoring** | Status of every stage, records processed / rejected, execution history, per-run summaries |
| **7. Report Generation** | Download cleaned data (CSV/Excel), rejected records, data-quality report (Markdown/JSON/CSV) and analytics summary (Markdown/Excel) |

## 🏗️ Architecture

```
                ┌──────────────┐   ┌───────────────┐   ┌───────────────┐   ┌──────────────┐
 CSV / XLSX ──▶ │ 1 Ingestion  │──▶│ 2 Data Quality│──▶│ 3 Transform   │──▶│ 4 SQLite     │
                │ validate+read│   │ report + score│   │ clean + reject│   │ raw_data     │
                └──────────────┘   └───────────────┘   └───────────────┘   │ clean_data   │
                                                                           │ rejected_data│
                         6 Monitoring (runs every stage, logs history) ───▶│ pipeline_runs│
                                                                           └──────┬───────┘
                                                      5 Analytics (SQL + Plotly) ◀┘──▶ 7 Reports
                                       app.py  (Streamlit UI, sidebar navigation)
```

**Design principle – separation of concerns:** everything in `modules/` is plain Python with no Streamlit
code. Only `app.py` draws the interface. That makes the logic easy to test (see `tests/`) and easy to explain.

## 📁 Project structure

```
DataPulse/
├── app.py                  # Streamlit UI and page router
├── requirements.txt        # Python dependencies
├── README.md
├── .gitignore
├── .streamlit/
│   └── config.toml         # navy / light-blue theme + server settings
├── modules/
│   ├── __init__.py
│   ├── ingestion.py        # upload validation, CSV/Excel reading, column mapping, demo data
│   ├── data_quality.py     # quality checks, score, report exports
│   ├── transformation.py   # cleaning rules → clean + rejected DataFrames
│   ├── database.py         # SQLite tables, loading, read-only SQL runner
│   ├── analytics.py        # SQL analytics, Plotly charts, report builders
│   └── monitoring.py       # pipeline orchestration + execution history
├── data/
│   ├── raw/                # copies of uploaded files (git-ignored)
│   └── processed/          # exported clean / rejected CSVs (git-ignored)
├── database/               # datapulse.db is created here (git-ignored)
├── assets/                 # logo, CSS, small demo dataset
└── tests/
    └── test_pipeline.py    # automated tests (unittest)
```

## 🚀 Quick start (GitHub Codespaces or any computer)

```bash
cd DataPulse
pip install -r requirements.txt
streamlit run app.py
```

In **Codespaces** a pop-up appears – tap **Open in Browser**. If you miss it, open the **Ports** tab and tap the
globe icon next to port **8501**.

**Try it immediately:** open *📥 Data Ingestion* → **Load demo dataset**, then *⚙️ ETL Pipeline* → **Run ETL pipeline**,
then *📈 Analytics Dashboard*.

### Using the real UCI Online Retail dataset

1. Download from <https://archive.ics.uci.edu/dataset/352/online+retail> and unzip to get `Online Retail.xlsx`.
2. Upload it on the *Data Ingestion* page.

Reading the 23 MB Excel file takes 1–2 minutes. **Faster option:** convert it to CSV once (run in the Codespaces terminal
in the folder containing the file) and upload the CSV instead:

```bash
python -c "import pandas as pd; pd.read_excel('Online Retail.xlsx').to_csv('online_retail.csv', index=False)"
```

The dataset has no Category column, so *category-wise performance* is shown only for files that include one
(the demo dataset does).

## 🧼 Cleaning rules (good to explain in an interview)

1. **Column recognition** – `Invoice`, `SKU`, `Qty`, `Price`, `Customer ID` … are mapped to the standard names.
2. **Standardise** – trim text, upper-case codes/descriptions, convert Quantity/UnitPrice to numbers and InvoiceDate to datetime.
3. **Reject** (kept in `rejected_data` with a reason): missing InvoiceNo/StockCode, bad date, bad quantity or price,
   zero quantity, zero or negative price, negative quantity without a cancellation invoice, cancelled invoice with
   positive quantity, non-product codes (postage, bank charges, manual adjustments), duplicates.
4. **Duplicates** – exact duplicate rows are removed; the first copy is kept.
5. **Missing values** – Description is filled from the most common description of the same StockCode;
   missing CustomerID → `Guest` (the sale is real, so the row is kept); missing Country → `Unknown`.
6. **Cancelled orders & returns** – invoices starting with `C` are **kept** as `TransactionType = Return` with negative
   quantity/revenue, so the dashboard can report gross revenue, returns and net revenue separately.
7. **Derived columns** – `Revenue = Quantity × UnitPrice`, `TransactionType`, `InvoiceMonth`.

**Revenue definitions:** *Total revenue* = gross sales (Sale lines only). *Net revenue* = gross − returns.
*Total orders* = distinct invoices with at least one sale line. Currency symbol is `£` (the dataset is in pounds);
change `CURRENCY` in `modules/analytics.py` for other data.

## 🧪 Run the tests

```bash
python -m unittest discover -s tests -v
```

The tests use temporary files, so your real database is never touched.

## ☁️ Deploy on Streamlit Community Cloud

1. Push this project to a **public GitHub repository** with `app.py` and `requirements.txt` at the top level.
2. Go to <https://share.streamlit.io>, sign in with GitHub and click **Create app** (deploy from an existing repo).
3. Choose your repository, branch `main`, and main file path `app.py`, then **Deploy**.
4. The first build installs the packages from `requirements.txt` (a few minutes).

Notes: the free tier has limited memory and a temporary file system – the SQLite file resets when the app restarts,
and very large Excel uploads may run out of memory. For big files, convert to CSV first, or use the demo dataset
for live demos.

## ⚠️ Limitations

* One dataset is active at a time; each pipeline run replaces the raw / clean / rejected tables (run history is kept).
* Only `.xlsx` Excel files are supported (not legacy `.xls`).
* Excel export of cleaned data is limited to 100,000 rows (use CSV for larger data).
* The `StockCode` list of non-product codes (`NON_PRODUCT_CODES` in `data_quality.py`) is tuned for the UCI dataset.

## 📚 Dataset

Chen, D. (2015). *Online Retail* [Dataset]. UCI Machine Learning Repository.
<https://archive.ics.uci.edu/dataset/352/online+retail>
