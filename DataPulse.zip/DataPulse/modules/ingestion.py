"""
Data Ingestion module.

Responsibilities
----------------
* Validate an uploaded file (type, size, not empty)
* Read CSV / Excel (.xlsx) into a pandas DataFrame
* Produce overview and per-column summaries for the UI
* Save a copy of the original upload into data/raw/
* Shared schema helpers (column-name mapping, date parsing) used by the
  data-quality and transformation modules
* Generate a small synthetic "demo" dataset that mimics the UCI Online Retail data

This module has NO Streamlit code.
"""
from __future__ import annotations

import io
import re
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "data" / "raw"
SAMPLE_FILE = BASE_DIR / "assets" / "sample_retail_data.csv"

SUPPORTED_EXTENSIONS = {".csv", ".xlsx"}
MAX_FILE_SIZE_MB = 100
# latin-1 can decode any byte, so it is the last resort
CSV_ENCODINGS = ("utf-8", "utf-8-sig", "latin-1")

# --------------------------------------------------------------------------
# Schema definition (shared by all modules)
# --------------------------------------------------------------------------
REQUIRED_COLUMNS = ["InvoiceNo", "StockCode", "Quantity", "InvoiceDate", "UnitPrice"]
OPTIONAL_COLUMNS = ["Description", "CustomerID", "Country", "Category"]
CANONICAL_COLUMNS = ["InvoiceNo", "StockCode", "Description", "Quantity",
                     "InvoiceDate", "UnitPrice", "CustomerID", "Country", "Category"]

# Lower-case, letters+digits only  ->  canonical name
_ALIASES = {
    "InvoiceNo": ["invoiceno", "invoice", "invoicenumber", "orderid", "orderno", "ordernumber"],
    "StockCode": ["stockcode", "sku", "productcode", "itemcode", "productid"],
    "Description": ["description", "productname", "product", "itemname", "itemdescription"],
    "Quantity": ["quantity", "qty", "unitssold", "units"],
    "InvoiceDate": ["invoicedate", "date", "orderdate", "invoicedatetime",
                    "transactiondate", "purchasedate"],
    "UnitPrice": ["unitprice", "price", "priceperunit", "sellingprice", "itemprice"],
    "CustomerID": ["customerid", "customer", "customerno", "custid", "customernumber"],
    "Country": ["country", "countryname"],
    "Category": ["category", "productcategory", "department"],
}
_ALIAS_LOOKUP = {alias: canon for canon, aliases in _ALIASES.items() for alias in aliases}


class IngestionError(Exception):
    """Raised for any problem a user should be told about in plain language."""


# --------------------------------------------------------------------------
# File validation and reading
# --------------------------------------------------------------------------
def validate_file(file_name: str, file_size_bytes: int,
                  max_size_mb: int = MAX_FILE_SIZE_MB) -> str:
    """Check extension and size. Returns the lower-case extension (e.g. '.csv')."""
    if not file_name:
        raise IngestionError("No file name was provided.")

    ext = Path(file_name).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise IngestionError(
            f"Unsupported file type '{ext or 'none'}'. "
            f"Please upload one of: {', '.join(sorted(SUPPORTED_EXTENSIONS))}."
        )
    if file_size_bytes == 0:
        raise IngestionError("The uploaded file is empty (0 bytes).")
    if file_size_bytes > max_size_mb * 1024 * 1024:
        raise IngestionError(f"File is larger than the {max_size_mb} MB limit.")
    return ext


def _read_csv(data: bytes) -> pd.DataFrame:
    """Try several encodings, because retail CSVs are often not UTF-8."""
    last_error: Exception | None = None
    for encoding in CSV_ENCODINGS:
        try:
            return pd.read_csv(io.BytesIO(data), encoding=encoding, low_memory=False)
        except UnicodeDecodeError as exc:
            last_error = exc
            continue
        except pd.errors.EmptyDataError as exc:
            raise IngestionError("The CSV file contains no data.") from exc
        except pd.errors.ParserError as exc:
            raise IngestionError(f"The CSV file is malformed: {exc}") from exc
    raise IngestionError(f"Could not decode the CSV file: {last_error}")


def _read_excel(data: bytes) -> pd.DataFrame:
    """Read the first sheet of an .xlsx file using openpyxl."""
    try:
        return pd.read_excel(io.BytesIO(data), engine="openpyxl")
    except ValueError as exc:
        raise IngestionError(f"Could not read the Excel file: {exc}") from exc
    except Exception as exc:  # corrupted zip, wrong format, etc.
        raise IngestionError(
            f"The Excel file appears to be corrupted or invalid: {exc}"
        ) from exc


def load_dataset(file_name: str, data: bytes) -> pd.DataFrame:
    """Validate and read an uploaded file (raw bytes) into a DataFrame."""
    ext = validate_file(file_name, len(data))
    df = _read_csv(data) if ext == ".csv" else _read_excel(data)

    if df.empty or df.shape[1] == 0:
        raise IngestionError("The file was read successfully but contains no rows.")

    # Clean header whitespace only. Cell values stay untouched (this is RAW data).
    df.columns = [str(c).strip() for c in df.columns]
    return df


def load_sample_dataset() -> pd.DataFrame:
    """Load the bundled demo dataset (or regenerate it if the file is missing)."""
    if SAMPLE_FILE.exists():
        return load_dataset(SAMPLE_FILE.name, SAMPLE_FILE.read_bytes())
    return generate_sample_dataset()


# --------------------------------------------------------------------------
# Summaries for the UI
# --------------------------------------------------------------------------
def get_dataset_overview(df: pd.DataFrame) -> dict:
    """High-level numbers shown in the metric cards."""
    total_cells = int(df.shape[0] * df.shape[1])
    missing_cells = int(df.isna().sum().sum())
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "memory_mb": round(float(df.memory_usage(deep=True).sum()) / (1024 ** 2), 2),
        "missing_cells": missing_cells,
        "missing_pct": round(missing_cells / total_cells * 100, 2) if total_cells else 0.0,
    }


def get_column_summary(df: pd.DataFrame) -> pd.DataFrame:
    """One row per column: data type, non-null count, missing count/%, unique values."""
    rows = len(df)
    missing = df.isna().sum().to_numpy()
    summary = pd.DataFrame({
        "Column": [str(c) for c in df.columns],
        "Data Type": [str(t) for t in df.dtypes],
        "Non-Null": df.notna().sum().to_numpy(),
        "Missing": missing,
        "Missing %": np.round(missing / rows * 100, 2) if rows else 0.0,
        "Unique Values": df.nunique(dropna=True).to_numpy(),
    })
    return summary.reset_index(drop=True)


def save_raw_copy(file_name: str, data: bytes, raw_dir: Path = RAW_DIR) -> Path:
    """Store the original upload in data/raw/ with a timestamp. Returns the path."""
    raw_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", Path(file_name).name)  # blocks path tricks
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = raw_dir / f"{stamp}_{safe_name}"
    target.write_bytes(data)
    return target


# --------------------------------------------------------------------------
# Shared schema helpers
# --------------------------------------------------------------------------
def _norm_key(name: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def detect_columns(df: pd.DataFrame) -> dict[str, str]:
    """Map ORIGINAL column name -> canonical DataPulse name (first match wins)."""
    mapping: dict[str, str] = {}
    used: set[str] = set()
    for col in df.columns:
        canon = _ALIAS_LOOKUP.get(_norm_key(col))
        if canon and canon not in used:
            mapping[str(col)] = canon
            used.add(canon)
    return mapping


def map_columns(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, str], list[str]]:
    """
    Rename recognised columns to the canonical names and drop the rest.

    Returns (mapped_df, mapping, missing_required_columns).
    """
    mapping = detect_columns(df)
    mapped = df[list(mapping.keys())].rename(columns=mapping)
    ordered = [c for c in CANONICAL_COLUMNS if c in mapped.columns]
    mapped = mapped[ordered]
    missing_required = [c for c in REQUIRED_COLUMNS if c not in mapped.columns]
    return mapped, mapping, missing_required


def parse_dates(series: pd.Series) -> pd.Series:
    """Convert a Series to datetime. Unparseable values become NaT (never raises)."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    parsed = pd.to_datetime(series, errors="coerce")
    retry = parsed.isna() & series.notna()
    if retry.any():  # second chance for columns that mix several date formats
        try:
            second = pd.to_datetime(series[retry], errors="coerce", format="mixed")
            parsed = parsed.copy()
            parsed.loc[retry] = second
        except (ValueError, TypeError):
            pass
    return parsed


# --------------------------------------------------------------------------
# Demo dataset generator
# --------------------------------------------------------------------------
_CATALOG = [
    # (StockCode, Description, Category, UnitPrice)
    ("85123A", "WHITE HANGING HEART T-LIGHT HOLDER", "Home Decor", 2.95),
    ("71053", "WHITE METAL LANTERN", "Home Decor", 3.39),
    ("84406B", "CREAM CUPID HEARTS COAT HANGER", "Home Decor", 2.75),
    ("22423", "REGENCY CAKESTAND 3 TIER", "Kitchen", 12.75),
    ("21730", "GLASS STAR FROSTED T-LIGHT HOLDER", "Home Decor", 4.25),
    ("22752", "SET 7 BABUSHKA NESTING BOXES", "Kitchen", 7.65),
    ("22633", "HAND WARMER UNION JACK", "Gifts", 1.85),
    ("22632", "HAND WARMER RED POLKA DOT", "Gifts", 1.85),
    ("84879", "ASSORTED COLOUR BIRD ORNAMENT", "Gifts", 1.69),
    ("22745", "POPPYS PLAYHOUSE BEDROOM", "Toys", 2.10),
    ("22748", "POPPYS PLAYHOUSE KITCHEN", "Toys", 2.10),
    ("22086", "PAPER CHAIN KIT 50'S CHRISTMAS", "Seasonal", 2.55),
    ("21212", "PACK OF 72 RETROSPOT CAKE CASES", "Kitchen", 0.55),
    ("23084", "RABBIT NIGHT LIGHT", "Toys", 2.08),
    ("22197", "SMALL POPCORN HOLDER", "Kitchen", 0.85),
    ("85099B", "JUMBO BAG RED RETROSPOT", "Bags", 2.08),
    ("47566", "PARTY BUNTING", "Seasonal", 4.95),
    ("20725", "LUNCH BAG RED RETROSPOT", "Bags", 1.65),
    ("22960", "JAM MAKING SET WITH JARS", "Kitchen", 4.25),
    ("22469", "HEART OF WICKER SMALL", "Home Decor", 1.65),
    ("21977", "PACK OF 60 PINK PAISLEY CAKE CASES", "Kitchen", 0.55),
    ("22139", "RETROSPOT TEA SET CERAMIC 11 PC", "Kitchen", 4.95),
    ("23166", "MEDIUM CERAMIC TOP STORAGE JAR", "Kitchen", 1.04),
    ("22386", "JUMBO BAG PINK POLKADOT", "Bags", 2.08),
    ("21931", "JUMBO STORAGE BAG SUKI", "Bags", 2.08),
    ("22111", "SCOTTIE DOG HOT WATER BOTTLE", "Gifts", 4.95),
    ("22457", "NATURAL SLATE HEART CHALKBOARD", "Home Decor", 2.95),
    ("23203", "JUMBO BAG DOILEY PATTERNS", "Bags", 2.08),
    ("22910", "PAPER CHAIN KIT VINTAGE CHRISTMAS", "Seasonal", 2.55),
    ("22178", "VICTORIAN GLASS HANGING T-LIGHT", "Home Decor", 1.25),
    ("84029G", "KNITTED UNION FLAG HOT WATER BOTTLE", "Gifts", 3.75),
    ("22960A", "WOODEN TRAIN SET 12 PIECES", "Toys", 6.95),
    ("22720", "SET OF 3 CAKE TINS PANTRY DESIGN", "Kitchen", 4.95),
    ("21034", "REX CASH+CARRY JUMBO SHOPPER", "Bags", 0.95),
    ("22411", "JUMBO SHOPPER VINTAGE RED PAISLEY", "Bags", 1.95),
    ("21080", "SET/20 RED RETROSPOT PAPER NAPKINS", "Kitchen", 0.85),
    ("22423B", "CHRISTMAS TREE DECORATION SET", "Seasonal", 3.25),
    ("22969", "HOMEMADE JAM SCENTED CANDLES", "Gifts", 1.25),
    ("22189", "CREAM HEART CARD HOLDER", "Gifts", 3.95),
]
_COUNTRIES = ["United Kingdom", "Germany", "France", "EIRE", "Spain",
              "Netherlands", "Belgium", "Switzerland", "Portugal", "Australia"]
_COUNTRY_WEIGHTS = [0.80, 0.045, 0.045, 0.03, 0.02, 0.015, 0.015, 0.01, 0.01, 0.01]


def generate_sample_dataset(n_invoices: int = 450, seed: int = 42) -> pd.DataFrame:
    """
    Create a small synthetic retail dataset with the same columns as the UCI
    Online Retail data (plus an optional Category column).

    The data deliberately contains realistic quality problems so every part of
    the pipeline has something to detect and fix: duplicates, missing values,
    cancelled invoices, zero/negative prices, bad dates and text in numeric fields.
    """
    rng = np.random.default_rng(seed)
    rows: list[dict] = []
    start = pd.Timestamp("2010-12-01")

    for i in range(n_invoices):
        invoice_no = 536000 + i
        when = start + pd.Timedelta(days=int(rng.integers(0, 395)),
                                    hours=int(rng.integers(8, 19)),
                                    minutes=int(rng.integers(0, 60)))
        customer = int(rng.integers(12346, 12346 + 120))
        country = str(rng.choice(_COUNTRIES, p=_COUNTRY_WEIGHTS))
        guest = rng.random() < 0.10
        for _ in range(int(rng.integers(1, 7))):
            code, desc, cat, price = _CATALOG[int(rng.integers(0, len(_CATALOG)))]
            rows.append({
                "InvoiceNo": str(invoice_no), "StockCode": code, "Description": desc,
                "Quantity": int(rng.integers(1, 25)),
                "InvoiceDate": when.strftime("%Y-%m-%d %H:%M:%S"),
                "UnitPrice": price,
                "CustomerID": np.nan if guest else float(customer),
                "Country": country, "Category": cat,
            })

    df = pd.DataFrame(rows)

    # Cancelled invoices (returns): ~4% of rows become "C" invoices with negative quantity
    cancel_idx = rng.choice(df.index, size=max(1, int(len(df) * 0.04)), replace=False)
    df.loc[cancel_idx, "InvoiceNo"] = "C" + df.loc[cancel_idx, "InvoiceNo"]
    df.loc[cancel_idx, "Quantity"] = -df.loc[cancel_idx, "Quantity"]

    # Missing descriptions
    df.loc[rng.choice(df.index, size=15, replace=False), "Description"] = np.nan

    # Invalid prices: zero (8 rows) and negative (3 rows)
    cancelled_set = set(cancel_idx)
    pool = [i for i in df.index if i not in cancelled_set]
    bad_price = rng.choice(pool, size=11, replace=False)
    df.loc[bad_price[:8], "UnitPrice"] = 0.0
    df.loc[bad_price[8:], "UnitPrice"] = -rng.uniform(5, 50, size=3).round(2)

    # Negative quantity on a normal invoice (stock adjustment / damaged goods)
    bad_price_set = set(bad_price)
    adj = rng.choice([i for i in pool if i not in bad_price_set], size=6, replace=False)
    df.loc[adj, "Quantity"] = -df.loc[adj, "Quantity"].abs()

    # Unparseable dates, missing invoice numbers, text in a numeric column
    df.loc[rng.choice(df.index, size=4, replace=False), "InvoiceDate"] = "not a date"
    df.loc[rng.choice(df.index, size=2, replace=False), "InvoiceNo"] = np.nan
    df["Quantity"] = df["Quantity"].astype(object)
    df.loc[rng.choice(df.index, size=2, replace=False), "Quantity"] = "abc"

    # A few non-product lines (postage etc.) and exact duplicate rows
    extra = df.sample(n=5, random_state=seed).copy()
    extra["StockCode"] = "POST"
    extra["Description"] = "POSTAGE"
    extra["Quantity"] = 1
    extra["UnitPrice"] = 18.0
    extra["Category"] = "Services"
    df = pd.concat([df, extra], ignore_index=True)
    df = pd.concat([df, df.sample(n=20, random_state=seed + 1)], ignore_index=True)

    return df.sample(frac=1, random_state=seed + 2).reset_index(drop=True)
