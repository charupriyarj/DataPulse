"""
Analytics module.

* SQL queries on the SQLite `clean_data` table (KPIs, monthly trend, top products,
  country sales, category performance, weekday pattern, returns)
* Plotly chart builders using the DataPulse navy / light-blue palette
* Report builders (analytics summary as Markdown / Excel, CSV / Excel download helpers)

Revenue definitions
-------------------
Gross revenue  = sum of Revenue on "Sale" lines
Returns value  = value of "Return" lines (cancelled invoices), shown as a positive number
Net revenue    = gross revenue - returns value
Total orders   = number of distinct invoices with at least one "Sale" line

This module has NO Streamlit code.
"""
from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from openpyxl.styles import Alignment, Font, PatternFill

from modules import database as db

CURRENCY = "£"  # the UCI Online Retail dataset is in pounds sterling
EXCEL_EXPORT_MAX_ROWS = 100_000  # Excel export of huge tables is slow and memory hungry

COLORS = {
    "navy": "#0B1F4B", "blue": "#2563EB", "sky": "#7DB4F0", "pale": "#DCEBFB",
    "grid": "#E3ECF7", "text": "#1B2B4B", "muted": "#5B6B8C", "white": "#FFFFFF",
}
FONT = "Inter, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif"


class AnalyticsError(Exception):
    """Raised when analytics cannot be produced (e.g. no cleaned data yet)."""


# --------------------------------------------------------------------------
# Query helpers
# --------------------------------------------------------------------------
def _where(filters: dict | None, extra: str | None = None) -> tuple[str, list]:
    """Build a parameterised WHERE clause from the dashboard filters."""
    conds: list[str] = [extra] if extra else []
    params: list = []
    f = filters or {}
    if f.get("start"):
        conds.append("InvoiceDate >= ?")
        params.append(f"{f['start']} 00:00:00")
    if f.get("end"):
        conds.append("InvoiceDate <= ?")
        params.append(f"{f['end']} 23:59:59")
    countries = f.get("countries")
    if countries:
        conds.append(f"Country IN ({', '.join('?' for _ in countries)})")
        params.extend(countries)
    return ("WHERE " + " AND ".join(conds)) if conds else "", params


def _query(sql: str, params: list | tuple = (), db_path: Path | str | None = None) -> pd.DataFrame:
    if not db.clean_data_ready(db_path):
        raise AnalyticsError("No cleaned data found. Run the ETL pipeline first.")
    try:
        with db.readonly(db_path) as conn:
            return pd.read_sql_query(sql, conn, params=params)
    except Exception as exc:  # sqlite3.Error / pandas DatabaseError
        raise AnalyticsError(f"Analytics query failed: {exc}") from exc


def has_category(db_path: Path | str | None = None) -> bool:
    try:
        return "Category" in db.get_clean_columns(db_path)
    except db.DatabaseError:
        return False


def get_filter_options(db_path: Path | str | None = None) -> dict:
    """Date range and country list for the dashboard filters."""
    span = _query(f"SELECT MIN(InvoiceDate) AS lo, MAX(InvoiceDate) AS hi FROM {db.TABLE_CLEAN}",
                  db_path=db_path)
    countries = _query(
        f"SELECT Country, SUM(Revenue) AS r FROM {db.TABLE_CLEAN} GROUP BY Country ORDER BY r DESC",
        db_path=db_path)
    return {
        "min_date": str(span.loc[0, "lo"])[:10], "max_date": str(span.loc[0, "hi"])[:10],
        "countries": countries["Country"].tolist(), "has_category": has_category(db_path),
    }


# --------------------------------------------------------------------------
# Analytics queries
# --------------------------------------------------------------------------
def get_kpis(filters: dict | None = None, db_path: Path | str | None = None) -> dict:
    where, params = _where(filters)
    df = _query(f"""
        SELECT
          COALESCE(SUM(CASE WHEN TransactionType='Sale'   THEN Revenue  END), 0) AS gross_revenue,
          COALESCE(-SUM(CASE WHEN TransactionType='Return' THEN Revenue  END), 0) AS returns_value,
          COUNT(DISTINCT CASE WHEN TransactionType='Sale'   THEN InvoiceNo END)    AS total_orders,
          COUNT(DISTINCT CASE WHEN TransactionType='Return' THEN InvoiceNo END)    AS return_orders,
          COALESCE(SUM(CASE WHEN TransactionType='Sale'   THEN Quantity END), 0)   AS units_sold,
          COALESCE(-SUM(CASE WHEN TransactionType='Return' THEN Quantity END), 0)  AS units_returned,
          COUNT(DISTINCT CASE WHEN CustomerID <> 'Guest' THEN CustomerID END)      AS customers
        FROM {db.TABLE_CLEAN} {where}""", params, db_path)
    r = df.iloc[0]
    gross, returns = float(r["gross_revenue"]), float(r["returns_value"])
    orders = int(r["total_orders"])
    return {
        "total_revenue": round(gross, 2),
        "returns_value": round(returns, 2),
        "net_revenue": round(gross - returns, 2),
        "total_orders": orders,
        "return_orders": int(r["return_orders"]),
        "units_sold": int(r["units_sold"]),
        "units_returned": int(r["units_returned"]),
        "customers": int(r["customers"]),
        "avg_order_value": round(gross / orders, 2) if orders else 0.0,
        "return_rate_pct": round(returns / gross * 100, 2) if gross else 0.0,
    }


def get_monthly_revenue(filters: dict | None = None, db_path: Path | str | None = None) -> pd.DataFrame:
    where, params = _where(filters)
    return _query(f"""
        SELECT InvoiceMonth AS Month,
               ROUND(SUM(CASE WHEN TransactionType='Sale' THEN Revenue ELSE 0 END), 2) AS Revenue,
               ROUND(-SUM(CASE WHEN TransactionType='Return' THEN Revenue ELSE 0 END), 2) AS Returns,
               COUNT(DISTINCT CASE WHEN TransactionType='Sale' THEN InvoiceNo END) AS Orders
        FROM {db.TABLE_CLEAN} {where}
        GROUP BY InvoiceMonth ORDER BY InvoiceMonth""", params, db_path)


_PRODUCT_SORT = {"Revenue": "Revenue", "Units": "Units"}  # whitelist: never put user text in ORDER BY


def get_top_products(metric: str = "Revenue", limit: int = 10, filters: dict | None = None,
                     db_path: Path | str | None = None) -> pd.DataFrame:
    order = _PRODUCT_SORT.get(metric, "Revenue")
    where, params = _where(filters, "TransactionType = 'Sale'")
    limit = max(1, min(int(limit), 50))
    return _query(f"""
        SELECT StockCode, Description, SUM(Quantity) AS Units, ROUND(SUM(Revenue), 2) AS Revenue
        FROM {db.TABLE_CLEAN} {where}
        GROUP BY StockCode, Description ORDER BY {order} DESC LIMIT {limit}""", params, db_path)


def get_country_sales(filters: dict | None = None, db_path: Path | str | None = None) -> pd.DataFrame:
    where, params = _where(filters, "TransactionType = 'Sale'")
    return _query(f"""
        SELECT Country, ROUND(SUM(Revenue), 2) AS Revenue,
               COUNT(DISTINCT InvoiceNo) AS Orders, SUM(Quantity) AS Units
        FROM {db.TABLE_CLEAN} {where}
        GROUP BY Country ORDER BY Revenue DESC""", params, db_path)


def get_category_performance(filters: dict | None = None,
                             db_path: Path | str | None = None) -> pd.DataFrame:
    """Only meaningful when the dataset has a Category column; otherwise returns an empty frame."""
    if not has_category(db_path):
        return pd.DataFrame(columns=["Category", "Revenue", "Orders", "Units"])
    where, params = _where(filters, "TransactionType = 'Sale'")
    return _query(f"""
        SELECT Category, ROUND(SUM(Revenue), 2) AS Revenue,
               COUNT(DISTINCT InvoiceNo) AS Orders, SUM(Quantity) AS Units
        FROM {db.TABLE_CLEAN} {where}
        GROUP BY Category ORDER BY Revenue DESC""", params, db_path)


def get_weekday_sales(filters: dict | None = None, db_path: Path | str | None = None) -> pd.DataFrame:
    where, params = _where(filters, "TransactionType = 'Sale'")
    df = _query(f"""
        SELECT CAST(strftime('%w', InvoiceDate) AS INTEGER) AS dow,
               ROUND(SUM(Revenue), 2) AS Revenue, COUNT(DISTINCT InvoiceNo) AS Orders
        FROM {db.TABLE_CLEAN} {where} GROUP BY dow""", params, db_path)
    names = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat"}
    order = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    df["Day"] = df["dow"].map(names)
    df = df.drop(columns="dow").set_index("Day").reindex(order).fillna(0).reset_index()
    return df


def get_top_returns(limit: int = 10, filters: dict | None = None,
                    db_path: Path | str | None = None) -> pd.DataFrame:
    where, params = _where(filters, "TransactionType = 'Return'")
    return _query(f"""
        SELECT StockCode, Description, -SUM(Quantity) AS UnitsReturned,
               ROUND(-SUM(Revenue), 2) AS ValueReturned
        FROM {db.TABLE_CLEAN} {where}
        GROUP BY StockCode, Description ORDER BY UnitsReturned DESC LIMIT {max(1, min(int(limit), 50))}""",
                  params, db_path)


# --------------------------------------------------------------------------
# Charts
# --------------------------------------------------------------------------
def _style(fig: go.Figure, title: str, height: int = 360) -> go.Figure:
    fig.update_layout(
        title=dict(text=title, x=0.01, xanchor="left", font=dict(size=16, color=COLORS["navy"])),
        template="plotly_white", height=height, font=dict(family=FONT, color=COLORS["text"], size=12),
        margin=dict(l=8, r=8, t=56, b=8), paper_bgcolor=COLORS["white"], plot_bgcolor=COLORS["white"],
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1.0),
        hoverlabel=dict(bgcolor=COLORS["navy"], font_color=COLORS["white"]),
    )
    fig.update_xaxes(gridcolor=COLORS["grid"], zeroline=False)
    fig.update_yaxes(gridcolor=COLORS["grid"], zeroline=False)
    return fig


def _shorten(text: str, n: int = 28) -> str:
    text = str(text)
    return text if len(text) <= n else text[: n - 1] + "…"


def fig_monthly_revenue(df: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df["Month"], y=df["Revenue"], name="Revenue", mode="lines+markers",
                             line=dict(color=COLORS["navy"], width=3), marker=dict(size=7),
                             fill="tozeroy", fillcolor="rgba(125,180,240,0.25)",
                             hovertemplate=f"%{{x}}<br>Revenue: {CURRENCY}%{{y:,.2f}}<extra></extra>"))
    fig.add_trace(go.Scatter(x=df["Month"], y=df["Returns"], name="Returns", mode="lines+markers",
                             line=dict(color=COLORS["sky"], width=2, dash="dot"), marker=dict(size=5),
                             hovertemplate=f"%{{x}}<br>Returns: {CURRENCY}%{{y:,.2f}}<extra></extra>"))
    fig.update_yaxes(tickprefix=CURRENCY, separatethousands=True)
    fig.update_xaxes(type="category")
    return _style(fig, "Monthly revenue trend")


def fig_top_products(df: pd.DataFrame, metric: str = "Revenue") -> go.Figure:
    d = df.copy().iloc[::-1]  # reverse so the biggest bar is on top
    d["Label"] = d["Description"].map(_shorten)
    is_money = metric == "Revenue"
    fig = go.Figure(go.Bar(
        x=d[metric], y=d["Label"], orientation="h", marker_color=COLORS["blue"],
        customdata=d[["StockCode", "Description"]],
        hovertemplate=("%{customdata[1]} (%{customdata[0]})<br>"
                       + (f"{CURRENCY}%{{x:,.2f}}" if is_money else "%{x:,} units") + "<extra></extra>")))
    if is_money:
        fig.update_xaxes(tickprefix=CURRENCY, separatethousands=True)
    return _style(fig, f"Top {len(d)} products by {metric.lower()}", height=max(320, 28 * len(d) + 110))


def fig_country_sales(df: pd.DataFrame, top_n: int = 10) -> go.Figure:
    d = df.head(top_n).iloc[::-1]
    fig = go.Figure(go.Bar(
        x=d["Revenue"], y=d["Country"], orientation="h", marker_color=COLORS["navy"],
        customdata=d[["Orders", "Units"]],
        hovertemplate=(f"%{{y}}<br>Revenue: {CURRENCY}%{{x:,.2f}}<br>Orders: %{{customdata[0]:,}}"
                       "<br>Units: %{customdata[1]:,}<extra></extra>")))
    fig.update_xaxes(tickprefix=CURRENCY, separatethousands=True)
    return _style(fig, f"Sales by country (top {len(d)})", height=max(320, 30 * len(d) + 110))


def fig_category(df: pd.DataFrame) -> go.Figure:
    d = df.copy()
    fig = px.bar(d, x="Category", y="Revenue", color_discrete_sequence=[COLORS["blue"]],
                 hover_data={"Orders": ":,", "Units": ":,"})
    fig.update_yaxes(tickprefix=CURRENCY, separatethousands=True)
    fig.update_xaxes(title=None)
    return _style(fig, "Category-wise performance")


def fig_weekday(df: pd.DataFrame) -> go.Figure:
    fig = go.Figure(go.Bar(x=df["Day"], y=df["Revenue"], marker_color=COLORS["sky"],
                           hovertemplate=f"%{{x}}<br>{CURRENCY}%{{y:,.2f}}<extra></extra>"))
    fig.update_yaxes(tickprefix=CURRENCY, separatethousands=True)
    return _style(fig, "Revenue by day of week")


def fig_quality_gauge(score: float) -> go.Figure:
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=score, number=dict(suffix=" / 100", font=dict(color=COLORS["navy"])),
        gauge=dict(axis=dict(range=[0, 100]), bar=dict(color=COLORS["navy"]),
                   steps=[dict(range=[0, 50], color="#EAF1FB"), dict(range=[50, 75], color="#CFE2F8"),
                          dict(range=[75, 90], color="#A9CCF3"), dict(range=[90, 100], color="#7DB4F0")])))
    fig.update_layout(height=250, margin=dict(l=20, r=20, t=30, b=10), paper_bgcolor=COLORS["white"],
                      font=dict(family=FONT))
    return fig


def fig_dimension_scores(dims: dict) -> go.Figure:
    names, values = list(dims.keys())[::-1], list(dims.values())[::-1]
    fig = go.Figure(go.Bar(x=values, y=names, orientation="h", marker_color=COLORS["blue"],
                           text=[f"{v}" for v in values], textposition="outside",
                           hovertemplate="%{y}: %{x}<extra></extra>"))
    fig.update_xaxes(range=[0, 108])
    return _style(fig, "Score breakdown", height=260)


def fig_rejection_reasons(reasons: dict) -> go.Figure:
    items = sorted(reasons.items(), key=lambda kv: kv[1])
    fig = go.Figure(go.Bar(x=[v for _, v in items], y=[_shorten(k, 40) for k, _ in items], orientation="h",
                           marker_color=COLORS["navy"], hovertemplate="%{y}: %{x:,}<extra></extra>"))
    return _style(fig, "Rejected records by reason", height=max(260, 34 * len(items) + 110))


def fig_run_history(history: pd.DataFrame) -> go.Figure:
    d = history.sort_values("run_id")
    labels = [f"#{i}" for i in d["run_id"]]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=labels, y=d["rows_clean"], name="Clean", marker_color=COLORS["blue"]))
    fig.add_trace(go.Bar(x=labels, y=d["rows_rejected"], name="Rejected", marker_color=COLORS["sky"]))
    fig.update_layout(barmode="stack")
    fig.update_xaxes(type="category", title="Run")
    return _style(fig, "Records processed per run")


# --------------------------------------------------------------------------
# Report / download helpers
# --------------------------------------------------------------------------
def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def dataframe_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "Data") -> bytes:
    """Excel export with a styled header row. Refuses very large tables (use CSV instead)."""
    if len(df) > EXCEL_EXPORT_MAX_ROWS:
        raise AnalyticsError(f"Excel export is limited to {EXCEL_EXPORT_MAX_ROWS:,} rows "
                             f"(this table has {len(df):,}). Please download the CSV instead.")
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name[:31])
        _style_sheet(writer.sheets[sheet_name[:31]], df)
    return buf.getvalue()


def _style_sheet(ws, df: pd.DataFrame) -> None:
    header_fill = PatternFill("solid", fgColor="0B1F4B")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(bold=True, color="FFFFFF")
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for i, col in enumerate(df.columns, start=1):
        sample = df[col].astype(str).head(200)
        width = max([len(str(col))] + [len(v) for v in sample]) + 2
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = min(width, 45)
    ws.freeze_panes = "A2"


def _kpi_rows(kpis: dict) -> list[tuple[str, float | int]]:
    return [
        ("Total revenue (gross sales)", kpis["total_revenue"]), ("Returns value", kpis["returns_value"]),
        ("Net revenue", kpis["net_revenue"]), ("Total orders", kpis["total_orders"]),
        ("Units sold", kpis["units_sold"]), ("Average order value", kpis["avg_order_value"]),
        ("Return rate (%)", kpis["return_rate_pct"]), ("Unique customers", kpis["customers"]),
    ]


def build_analytics_summary_md(kpis: dict, monthly: pd.DataFrame, products: pd.DataFrame,
                               countries: pd.DataFrame, categories: pd.DataFrame | None = None,
                               filters_text: str = "All data") -> bytes:
    """Plain-language analytics summary in Markdown."""
    L = ["# DataPulse - Analytics Summary", f"_Generated: {datetime.now():%Y-%m-%d %H:%M:%S}_",
         f"_Filters: {filters_text}_\n", "## Key metrics",
         f"- **Total revenue:** {CURRENCY}{kpis['total_revenue']:,.2f}",
         f"- **Net revenue (after returns):** {CURRENCY}{kpis['net_revenue']:,.2f}",
         f"- **Total orders:** {kpis['total_orders']:,}",
         f"- **Units sold:** {kpis['units_sold']:,}",
         f"- **Average order value:** {CURRENCY}{kpis['avg_order_value']:,.2f}",
         f"- **Returns:** {CURRENCY}{kpis['returns_value']:,.2f} ({kpis['return_rate_pct']}% of revenue)",
         f"- **Unique customers (excluding guests):** {kpis['customers']:,}", "", "## Highlights"]
    if not monthly.empty:
        best = monthly.loc[monthly["Revenue"].idxmax()]
        L.append(f"- Best month: **{best['Month']}** with {CURRENCY}{best['Revenue']:,.2f}")
    if not products.empty:
        L.append(f"- Top product: **{products.iloc[0]['Description']}** "
                 f"({CURRENCY}{products.iloc[0]['Revenue']:,.2f})")
    if not countries.empty:
        share = countries.iloc[0]["Revenue"] / countries["Revenue"].sum() * 100
        L.append(f"- Top country: **{countries.iloc[0]['Country']}** ({share:.1f}% of revenue)")
    if categories is not None and not categories.empty:
        L.append(f"- Top category: **{categories.iloc[0]['Category']}** "
                 f"({CURRENCY}{categories.iloc[0]['Revenue']:,.2f})")

    def table(title: str, df: pd.DataFrame) -> None:
        L.extend(["", f"## {title}", "| " + " | ".join(df.columns) + " |",
                  "|" + "---|" * len(df.columns)])
        for _, r in df.iterrows():
            L.append("| " + " | ".join(f"{v:,.2f}" if isinstance(v, float) else str(v) for v in r) + " |")

    if not monthly.empty:
        table("Monthly revenue", monthly)
    if not products.empty:
        table("Top products", products)
    if not countries.empty:
        table("Sales by country", countries.head(15))
    if categories is not None and not categories.empty:
        table("Category performance", categories)
    return ("\n".join(L) + "\n").encode("utf-8")


def build_analytics_excel(kpis: dict, monthly: pd.DataFrame, products: pd.DataFrame,
                          countries: pd.DataFrame, categories: pd.DataFrame | None = None) -> bytes:
    """Multi-sheet Excel workbook with the analytics tables."""
    sheets = {"KPIs": pd.DataFrame(_kpi_rows(kpis), columns=["Metric", "Value"]),
              "Monthly revenue": monthly, "Top products": products, "Countries": countries}
    if categories is not None and not categories.empty:
        sheets["Categories"] = categories
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for name, frame in sheets.items():
            frame.to_excel(writer, index=False, sheet_name=name[:31])
            _style_sheet(writer.sheets[name[:31]], frame)
    return buf.getvalue()
