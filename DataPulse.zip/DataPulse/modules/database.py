"""
Database module (SQLite).

Tables
------
raw_data        the uploaded data, exactly as read (before cleaning)
clean_data      the cleaned, analytics-ready data (explicit schema + indexes)
rejected_data   every row the ETL rejected, with RejectReason
pipeline_runs   execution history (managed by monitoring.py)

SQLite is built into Python, so nothing extra needs installing.

SECURITY: user-written SQL (the SQL playground) is validated and executed on a
READ-ONLY connection, so it cannot modify or delete data.

This module has NO Streamlit code.
"""
from __future__ import annotations

import re
import sqlite3
from contextlib import closing, contextmanager
from datetime import date, datetime
from pathlib import Path

import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DB_DIR = BASE_DIR / "database"
DB_PATH = DB_DIR / "datapulse.db"

TABLE_RAW = "raw_data"
TABLE_CLEAN = "clean_data"
TABLE_REJECTED = "rejected_data"
TABLE_RUNS = "pipeline_runs"
DATA_TABLES = (TABLE_RAW, TABLE_CLEAN, TABLE_REJECTED)
ALL_TABLES = DATA_TABLES + (TABLE_RUNS,)

CHUNK_SIZE = 20_000
MAX_QUERY_ROWS = 5_000

_CLEAN_COLUMN_TYPES = {
    "InvoiceNo": "TEXT NOT NULL", "StockCode": "TEXT NOT NULL", "Description": "TEXT",
    "Quantity": "INTEGER NOT NULL", "UnitPrice": "REAL NOT NULL", "InvoiceDate": "TEXT NOT NULL",
    "CustomerID": "TEXT", "Country": "TEXT", "Category": "TEXT",
    "Revenue": "REAL NOT NULL", "TransactionType": "TEXT NOT NULL", "InvoiceMonth": "TEXT NOT NULL",
}
_CLEAN_INDEXES = ["InvoiceMonth", "Country", "StockCode", "InvoiceNo", "TransactionType"]

# Ready-made queries for the SQL playground (also good for demos)
SAMPLE_QUERIES = {
    "Top 10 products by revenue": (
        "SELECT StockCode, Description, SUM(Quantity) AS units_sold, ROUND(SUM(Revenue), 2) AS revenue\n"
        "FROM clean_data\nWHERE TransactionType = 'Sale'\nGROUP BY StockCode, Description\n"
        "ORDER BY revenue DESC\nLIMIT 10;"),
    "Revenue by country": (
        "SELECT Country, COUNT(DISTINCT InvoiceNo) AS orders, ROUND(SUM(Revenue), 2) AS revenue\n"
        "FROM clean_data\nWHERE TransactionType = 'Sale'\nGROUP BY Country\nORDER BY revenue DESC;"),
    "Monthly revenue": (
        "SELECT InvoiceMonth, ROUND(SUM(Revenue), 2) AS revenue\nFROM clean_data\n"
        "WHERE TransactionType = 'Sale'\nGROUP BY InvoiceMonth\nORDER BY InvoiceMonth;"),
    "Top 10 customers": (
        "SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS orders, ROUND(SUM(Revenue), 2) AS spent\n"
        "FROM clean_data\nWHERE TransactionType = 'Sale' AND CustomerID <> 'Guest'\n"
        "GROUP BY CustomerID\nORDER BY spent DESC\nLIMIT 10;"),
    "Most returned products": (
        "SELECT StockCode, Description, -SUM(Quantity) AS units_returned\nFROM clean_data\n"
        "WHERE TransactionType = 'Return'\nGROUP BY StockCode, Description\n"
        "ORDER BY units_returned DESC\nLIMIT 10;"),
    "Rejected rows by reason": (
        "SELECT RejectReason, COUNT(*) AS rows_rejected\nFROM rejected_data\n"
        "GROUP BY RejectReason\nORDER BY rows_rejected DESC;"),
    "Pipeline run history": (
        "SELECT run_id, source_file, status, started_at, rows_input, rows_clean, rows_rejected\n"
        "FROM pipeline_runs\nORDER BY run_id DESC\nLIMIT 20;"),
}


class DatabaseError(Exception):
    """Raised for database problems that should be explained to the user."""


# --------------------------------------------------------------------------
# Connections
# --------------------------------------------------------------------------
def get_connection(db_path: Path | str | None = None) -> sqlite3.Connection:
    """Open a read/write connection (creating the database file if needed)."""
    path = Path(db_path) if db_path else DB_PATH
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        return sqlite3.connect(str(path))
    except (sqlite3.Error, OSError) as exc:
        raise DatabaseError(f"Could not open the database at {path}: {exc}") from exc


def get_readonly_connection(db_path: Path | str | None = None) -> sqlite3.Connection:
    """Open a connection that cannot change anything."""
    path = Path(db_path) if db_path else DB_PATH
    if not path.exists():
        raise DatabaseError("The database does not exist yet. Run the ETL pipeline first.")
    try:
        conn = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True)
        conn.execute("PRAGMA query_only = ON")
        return conn
    except sqlite3.Error as exc:
        raise DatabaseError(f"Could not open the database read-only: {exc}") from exc


@contextmanager
def readonly(db_path: Path | str | None = None):
    """Context manager: open a read-only connection and always close it."""
    conn = get_readonly_connection(db_path)
    try:
        yield conn
    finally:
        conn.close()


# --------------------------------------------------------------------------
# Writing data
# --------------------------------------------------------------------------
def _sql_safe(value):
    """Convert values SQLite cannot store (timestamps, numpy scalars) to plain Python."""
    if value is None or value is pd.NaT:
        return None
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, np.generic):
        return value.item()
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return value


def _prepare_for_sql(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c) for c in out.columns]
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].dt.strftime("%Y-%m-%d %H:%M:%S")
        elif out[col].dtype == object:
            out[col] = out[col].map(_sql_safe).astype(object)
    return out


def _write_table(df: pd.DataFrame, table: str, conn: sqlite3.Connection) -> int:
    try:
        _prepare_for_sql(df).to_sql(table, conn, if_exists="replace", index=False,
                                    chunksize=CHUNK_SIZE)
        conn.commit()
    except (sqlite3.Error, ValueError) as exc:
        raise DatabaseError(f"Could not write table '{table}': {exc}") from exc
    return len(df)


def save_raw(df: pd.DataFrame, conn: sqlite3.Connection) -> int:
    """Store the uploaded data untouched in raw_data. Returns rows written."""
    return _write_table(df, TABLE_RAW, conn)


def save_rejected(df: pd.DataFrame, conn: sqlite3.Connection) -> int:
    """Store rejected rows (with RejectReason) in rejected_data."""
    return _write_table(df, TABLE_REJECTED, conn)


def save_clean(df: pd.DataFrame, conn: sqlite3.Connection) -> int:
    """Create clean_data with an explicit schema + indexes and load the cleaned rows."""
    unknown = [c for c in df.columns if c not in _CLEAN_COLUMN_TYPES]
    if unknown:
        raise DatabaseError(f"Unexpected columns in cleaned data: {unknown}")
    columns_sql = ",\n  ".join(f'"{c}" {_CLEAN_COLUMN_TYPES[c]}' for c in df.columns)
    try:
        conn.execute(f"DROP TABLE IF EXISTS {TABLE_CLEAN}")
        conn.execute(f"CREATE TABLE {TABLE_CLEAN} (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  {columns_sql}\n)")
        _prepare_for_sql(df).to_sql(TABLE_CLEAN, conn, if_exists="append", index=False,
                                    chunksize=CHUNK_SIZE)
        for col in _CLEAN_INDEXES:
            if col in df.columns:
                conn.execute(f'CREATE INDEX IF NOT EXISTS idx_clean_{col.lower()} '
                             f'ON {TABLE_CLEAN}("{col}")')
        conn.commit()
    except (sqlite3.Error, ValueError) as exc:
        raise DatabaseError(f"Could not write table '{TABLE_CLEAN}': {exc}") from exc
    return len(df)


# --------------------------------------------------------------------------
# Reading data and metadata
# --------------------------------------------------------------------------
def table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
    return row is not None


def count_rows(conn: sqlite3.Connection, table: str) -> int:
    if table not in ALL_TABLES or not table_exists(conn, table):
        return 0
    return int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])


def get_table_schema(table: str, db_path: Path | str | None = None) -> pd.DataFrame:
    """Column names/types of a table (PRAGMA table_info)."""
    if table not in ALL_TABLES:
        raise DatabaseError(f"Unknown table '{table}'.")
    with readonly(db_path) as conn:
        info = pd.read_sql_query(f'PRAGMA table_info("{table}")', conn)
    if info.empty:
        return pd.DataFrame(columns=["Column", "Type", "Not Null", "Primary Key"])
    return pd.DataFrame({"Column": info["name"], "Type": info["type"],
                         "Not Null": info["notnull"].astype(bool), "Primary Key": info["pk"].astype(bool)})


def read_table(table: str, limit: int = 100, offset: int = 0,
               db_path: Path | str | None = None) -> pd.DataFrame:
    """Return a page of rows from one of the DataPulse tables."""
    if table not in ALL_TABLES:
        raise DatabaseError(f"Unknown table '{table}'.")
    limit = max(1, min(int(limit), MAX_QUERY_ROWS))
    offset = max(0, int(offset))
    with readonly(db_path) as conn:
        if not table_exists(conn, table):
            raise DatabaseError(f"Table '{table}' does not exist yet. Run the ETL pipeline first.")
        return pd.read_sql_query(f'SELECT * FROM "{table}" LIMIT ? OFFSET ?', conn, params=(limit, offset))


def read_full_table(table: str, db_path: Path | str | None = None) -> pd.DataFrame:
    """Read an entire table (used for downloads)."""
    if table not in ALL_TABLES:
        raise DatabaseError(f"Unknown table '{table}'.")
    with readonly(db_path) as conn:
        if not table_exists(conn, table):
            raise DatabaseError(f"Table '{table}' does not exist yet. Run the ETL pipeline first.")
        return pd.read_sql_query(f'SELECT * FROM "{table}"', conn)


def get_database_info(db_path: Path | str | None = None) -> dict:
    """File size and row count of every table (safe to call before the DB exists)."""
    path = Path(db_path) if db_path else DB_PATH
    info = {"path": str(path), "exists": path.exists(), "size_mb": 0.0, "tables": []}
    if not path.exists():
        return info
    info["size_mb"] = round(path.stat().st_size / (1024 ** 2), 2)
    with readonly(path) as conn:
        for table in ALL_TABLES:
            if table_exists(conn, table):
                info["tables"].append({"Table": table, "Rows": count_rows(conn, table)})
    return info


def clean_data_ready(db_path: Path | str | None = None) -> bool:
    """True when clean_data exists and has at least one row."""
    path = Path(db_path) if db_path else DB_PATH
    if not path.exists():
        return False
    try:
        with readonly(path) as conn:
            return count_rows(conn, TABLE_CLEAN) > 0
    except DatabaseError:
        return False


def get_clean_columns(db_path: Path | str | None = None) -> list[str]:
    schema = get_table_schema(TABLE_CLEAN, db_path)
    return schema["Column"].tolist()


# --------------------------------------------------------------------------
# SQL playground
# --------------------------------------------------------------------------
_FORBIDDEN = re.compile(r"\b(insert|update|delete|drop|alter|create|attach|detach|replace|vacuum|pragma)\b",
                        re.IGNORECASE)


def validate_select(sql: str) -> str:
    """Return a cleaned single SELECT/WITH statement or raise DatabaseError."""
    if not sql or not sql.strip():
        raise DatabaseError("Please type a SQL query first.")
    cleaned = re.sub(r"--[^\n]*", "", sql)                 # strip line comments
    cleaned = re.sub(r"/\*.*?\*/", "", cleaned, flags=re.S)  # strip block comments
    cleaned = cleaned.strip().rstrip(";").strip()
    if ";" in cleaned:
        raise DatabaseError("Only one SQL statement can be run at a time.")
    if not re.match(r"^(select|with)\b", cleaned, re.IGNORECASE):
        raise DatabaseError("Only SELECT queries are allowed here.")
    if _FORBIDDEN.search(cleaned):
        raise DatabaseError("This query contains a keyword that is not allowed "
                            "(INSERT, UPDATE, DELETE, DROP, ALTER, CREATE, PRAGMA ...).")
    return cleaned


def run_select_query(sql: str, db_path: Path | str | None = None,
                     max_rows: int = MAX_QUERY_ROWS) -> pd.DataFrame:
    """Validate and run a read-only query; at most `max_rows` rows are returned."""
    cleaned = validate_select(sql)
    try:
        with readonly(db_path) as conn:
            return pd.read_sql_query(f"SELECT * FROM (\n{cleaned}\n) LIMIT {int(max_rows)}", conn)
    except (sqlite3.Error, pd.errors.DatabaseError) as exc:
        raise DatabaseError(f"SQL error: {exc}") from exc


# --------------------------------------------------------------------------
# Maintenance
# --------------------------------------------------------------------------
def reset_database(keep_history: bool = True, db_path: Path | str | None = None) -> None:
    """Drop raw/clean/rejected tables (and optionally the run history)."""
    tables = DATA_TABLES if keep_history else ALL_TABLES
    with closing(get_connection(db_path)) as conn:
        for table in tables:
            conn.execute(f'DROP TABLE IF EXISTS "{table}"')
        conn.commit()
        conn.execute("VACUUM")
