"""
Transformation module (the "T" in ETL).

Takes the RAW retail DataFrame and returns:
  * a CLEAN DataFrame ready for analytics
  * a REJECTED DataFrame (every dropped row, with the reason why)
  * statistics + a step log describing what was done

Cleaning rules
--------------
1. Recognise columns (e.g. "Invoice" -> InvoiceNo) and drop unknown columns.
2. Trim / standardise text (upper-case codes and descriptions, collapse spaces).
3. Convert Quantity and UnitPrice to numbers, InvoiceDate to datetime.
4. Reject rows that cannot be trusted (see REJECT_RULES below).
5. Remove exact duplicate rows (first copy is kept).
6. Fill missing values:
     Description -> most common description for the same StockCode ("UNKNOWN PRODUCT" if none)
     CustomerID  -> "Guest"   (revenue is still valid, so the row is kept)
     Country     -> "Unknown"
     Category    -> "Uncategorized"
7. Cancelled invoices (InvoiceNo starts with "C") are KEPT as TransactionType = "Return"
   with negative Quantity/Revenue, so analytics can report gross sales, returns and net revenue.
8. Add helper columns: Revenue, TransactionType, InvoiceMonth.

This module has NO Streamlit code.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from modules.data_quality import cancelled_mask, non_product_mask
from modules.ingestion import map_columns, parse_dates

CLEAN_COLUMNS = ["InvoiceNo", "StockCode", "Description", "Quantity", "UnitPrice",
                 "InvoiceDate", "CustomerID", "Country", "Category",
                 "Revenue", "TransactionType", "InvoiceMonth"]

COUNTRY_FIXES = {"EIRE": "Ireland", "RSA": "South Africa", "USA": "United States",
                 "UK": "United Kingdom", "UNSPECIFIED": "Unknown"}

# Order matters: a row gets the FIRST reason that applies.
REJECT_RULES = [
    "Missing InvoiceNo",
    "Missing StockCode",
    "Invalid or missing InvoiceDate",
    "Invalid or missing Quantity",
    "Invalid or missing UnitPrice",
    "Zero Quantity",
    "Negative UnitPrice",
    "Zero UnitPrice",
    "Cancelled invoice with positive Quantity",
    "Negative Quantity without cancellation invoice",
    "Non-product code (postage / fees / adjustments)",
    "Duplicate record",
]


class TransformationError(Exception):
    """Raised when the data cannot be transformed (e.g. required columns missing)."""


@dataclass
class CleaningResult:
    clean: pd.DataFrame
    rejected: pd.DataFrame
    stats: dict
    steps: list[dict] = field(default_factory=list)


def _clean_text(series: pd.Series, upper: bool = False) -> pd.Series:
    """Trim, collapse repeated spaces, turn empty strings into missing values."""
    t = series.astype("string").str.strip().str.replace(r"\s+", " ", regex=True)
    t = t.mask(t.eq("").fillna(False).astype(bool))
    return t.str.upper() if upper else t


def _to_float(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").astype("float64")


def _empty_text(index: pd.Index) -> pd.Series:
    return pd.Series(pd.NA, index=index, dtype="string")


def clean_dataset(df_raw: pd.DataFrame) -> CleaningResult:
    """Run the full cleaning process. Never modifies df_raw."""
    if df_raw is None or df_raw.empty:
        raise TransformationError("There is no data to transform.")

    mapped, mapping, missing_required = map_columns(df_raw)
    if missing_required:
        raise TransformationError(
            "Required column(s) missing: " + ", ".join(missing_required) +
            ". Expected columns like InvoiceNo, StockCode, Quantity, InvoiceDate, UnitPrice."
        )

    steps: list[dict] = []
    rows_in = len(mapped)
    idx = mapped.index
    dropped_cols = [str(c) for c in df_raw.columns if str(c) not in mapping]
    steps.append({"step": "Standardise columns",
                  "detail": f"Recognised {len(mapping)} columns"
                            + (f"; ignored {len(dropped_cols)} unknown column(s): {', '.join(dropped_cols)}"
                               if dropped_cols else "")})

    # ---- 1. standardise values (on copies; `mapped` keeps the raw values) -------
    s = pd.DataFrame(index=idx)
    s["InvoiceNo"] = _clean_text(mapped["InvoiceNo"], upper=True)
    s["StockCode"] = _clean_text(mapped["StockCode"], upper=True)
    s["Description"] = (_clean_text(mapped["Description"], upper=True)
                        if "Description" in mapped else _empty_text(idx))
    s["Country"] = _clean_text(mapped["Country"]) if "Country" in mapped else _empty_text(idx)
    s["Category"] = _clean_text(mapped["Category"]) if "Category" in mapped else _empty_text(idx)

    cid = _clean_text(mapped["CustomerID"]) if "CustomerID" in mapped else _empty_text(idx)
    num = _to_float(cid)  # "17850.0" -> 17850.0 -> "17850"
    integral = (num.notna() & (num % 1 == 0)).to_numpy()
    as_int_text = num.where(integral).astype("Int64").astype("string")
    s["CustomerID"] = cid.mask(integral, as_int_text)

    qty = _to_float(mapped["Quantity"])
    price = _to_float(mapped["UnitPrice"])
    date = parse_dates(mapped["InvoiceDate"])
    steps.append({"step": "Standardise formats",
                  "detail": "Trimmed text, upper-cased codes/descriptions, converted Quantity and "
                            "UnitPrice to numbers and InvoiceDate to datetime"})

    # ---- 2. reject untrustworthy rows ----------------------------------------
    reason = pd.Series([None] * rows_in, index=idx, dtype="object")

    def assign(mask: pd.Series, text: str) -> None:
        m = pd.Series(mask, index=idx).fillna(False).astype(bool) & reason.isna()
        reason.loc[m] = text

    cancelled = cancelled_mask(s["InvoiceNo"])
    assign(s["InvoiceNo"].isna(), REJECT_RULES[0])
    assign(s["StockCode"].isna(), REJECT_RULES[1])
    assign(date.isna(), REJECT_RULES[2])
    assign(qty.isna(), REJECT_RULES[3])
    assign(price.isna(), REJECT_RULES[4])
    assign(qty == 0, REJECT_RULES[5])
    assign(price < 0, REJECT_RULES[6])
    assign(price == 0, REJECT_RULES[7])
    assign(cancelled & (qty > 0), REJECT_RULES[8])
    assign(~cancelled & (qty < 0), REJECT_RULES[9])
    assign(non_product_mask(s["StockCode"]), REJECT_RULES[10])

    key = pd.DataFrame({"a": s["InvoiceNo"], "b": s["StockCode"], "c": s["Description"],
                        "d": qty, "e": date, "f": price, "g": s["CustomerID"], "h": s["Country"]})
    assign(key.duplicated(keep="first"), REJECT_RULES[11])

    valid = reason.isna().to_numpy()
    counts = reason.dropna().value_counts()
    reasons = {r: int(counts[r]) for r in REJECT_RULES if r in counts}
    rows_rejected = int((~valid).sum())
    steps.append({"step": "Validate rows",
                  "detail": f"Rejected {rows_rejected:,} of {rows_in:,} rows"})
    steps.append({"step": "Remove duplicates",
                  "detail": f"Removed {reasons.get('Duplicate record', 0):,} exact duplicate rows"})

    rejected = mapped.loc[~valid].copy()
    rejected.insert(0, "SourceRow", np.flatnonzero(~valid) + 2)  # +2: header is row 1
    rejected["RejectReason"] = reason.loc[~valid].to_numpy()
    rejected = rejected.reset_index(drop=True)

    if valid.sum() == 0:
        raise TransformationError(
            "Every row was rejected, so there is nothing to load. "
            "Check the Data Quality page to see what is wrong with the file."
        )

    # ---- 3. build the clean table from the valid rows ---------------------------
    v = pd.Series(valid, index=idx)
    stock_v = s.loc[v, "StockCode"]
    desc_v = s.loc[v, "Description"]

    # most common description per StockCode (also standardises spelling variants)
    known = pd.DataFrame({"StockCode": stock_v, "Description": desc_v}).dropna()
    if len(known):
        best = (known.groupby(["StockCode", "Description"]).size().reset_index(name="n")
                .sort_values(["StockCode", "n", "Description"], ascending=[True, False, True])
                .drop_duplicates("StockCode").set_index("StockCode")["Description"])
        canonical = stock_v.map(best)
    else:
        canonical = _empty_text(stock_v.index)
    desc_filled = int((desc_v.isna() & canonical.notna()).sum())
    desc_variants = int((desc_v.notna() & canonical.notna() & (desc_v != canonical)).sum())
    final_desc = canonical.astype("string").fillna("UNKNOWN PRODUCT")
    desc_unknown = int((final_desc == "UNKNOWN PRODUCT").sum())

    guest_rows = int(s.loc[v, "CustomerID"].isna().sum())
    country_missing = int(s.loc[v, "Country"].isna().sum())

    ctry = s.loc[v, "Country"]
    fixed = ctry.str.upper().map(COUNTRY_FIXES)
    ctry = ctry.where(fixed.isna(), fixed).astype("string").fillna("Unknown")

    qty_v = qty.loc[v]
    if (qty_v == qty_v.round()).all():
        qty_v = qty_v.astype("int64")
    price_v = price.loc[v].round(4)
    date_v = date.loc[v]
    cancelled_v = cancelled.loc[v]

    clean = pd.DataFrame({
        "InvoiceNo": s.loc[v, "InvoiceNo"].astype(str),
        "StockCode": stock_v.astype(str),
        "Description": final_desc.astype(str),
        "Quantity": qty_v,
        "UnitPrice": price_v,
        "InvoiceDate": date_v,
        "CustomerID": s.loc[v, "CustomerID"].astype("string").fillna("Guest").astype(str),
        "Country": ctry.astype(str),
    })
    if "Category" in mapped:
        clean["Category"] = (s.loc[v, "Category"].astype("string")
                             .fillna("Uncategorized").astype(str))
    clean["Revenue"] = (qty_v * price_v).round(2)
    clean["TransactionType"] = np.where(cancelled_v, "Return", "Sale")
    clean["InvoiceMonth"] = date_v.dt.strftime("%Y-%m")
    clean = clean[[c for c in CLEAN_COLUMNS if c in clean.columns]].reset_index(drop=True)

    steps.append({"step": "Handle missing values",
                  "detail": f"Filled {desc_filled:,} missing descriptions from StockCode"
                            f" ({desc_unknown:,} still unknown), labelled {guest_rows:,} rows without"
                            f" CustomerID as 'Guest', filled {country_missing:,} missing countries"})
    n_returns = int((clean["TransactionType"] == "Return").sum())
    steps.append({"step": "Handle cancelled orders",
                  "detail": f"Kept {n_returns:,} cancelled/returned lines as TransactionType='Return' "
                            "with negative quantity and revenue"})
    steps.append({"step": "Add derived columns", "detail": "Revenue, TransactionType, InvoiceMonth"})

    rows_clean = len(clean)
    if rows_clean + rows_rejected != rows_in:  # internal sanity check
        raise TransformationError("Row count mismatch after cleaning - this is a bug.")

    stats = {
        "rows_input": int(rows_in),
        "rows_clean": int(rows_clean),
        "rows_rejected": rows_rejected,
        "duplicates_removed": reasons.get("Duplicate record", 0),
        "rejection_reasons": reasons,
        "descriptions_filled": desc_filled,
        "descriptions_standardised": desc_variants,
        "guest_rows": guest_rows,
        "countries_filled": country_missing,
        "sale_rows": int(rows_clean - n_returns),
        "return_rows": n_returns,
        "ignored_columns": dropped_cols,
        "has_category": "Category" in clean.columns,
    }
    return CleaningResult(clean=clean, rejected=rejected, stats=stats, steps=steps)
