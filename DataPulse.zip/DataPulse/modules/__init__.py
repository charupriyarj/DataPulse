"""DataPulse modules package.

Each module contains plain Python logic (no Streamlit code) so it can be
tested on its own. Only app.py talks to the user interface.
"""
