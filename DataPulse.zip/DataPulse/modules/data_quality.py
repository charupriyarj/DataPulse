"""
Data Quality Checker module.

Scans a raw retail DataFrame and produces a quality report:
  * missing values (per column)
  * duplicate records
  * invalid values (bad quantities, prices, dates, stock codes ...)
  * incorrect data types
  * a 0-100 quality score with a letter grade and recommendations

The report is a plain, JSON-friendly Python dict, so it can be stored in SQLite,
exported as JSON/Markdown/CSV, and displayed in Streamlit without conversion.

This module has NO Streamlit code and does NOT change the data it inspects.
"""
from __future__ import annotations

import json
from datetime import datetime

import numpy as np
import pandas as pd

from modules.ingestion import map_columns, parse_dates

# Codes in the UCI dataset that are fees/adjustments rather than real products.
NON_PRODUCT_CODES = frozenset({
    "POST", "D", "DOT", "M", "BANK CHARGES", "C2", "CRUK", "S", "AMAZONFEE", "B",
    "PADS", "ADJUST", "ADJUST2", "TEST001", "TEST002",
})

# Score weights (must add up to 1.0)
SCORE_WEIGHTS = {"Completeness": 0.30, "Uniqueness": 0.20, "Validity": 0.35, "Type consistency": 0.15}

EXPECTED_TYPES = {
    "InvoiceNo": "text", "StockCode": "text", "Description": "text",
    "Quantity": "numeric", "InvoiceDate": "datetime", "UnitPrice": "numeric",
    "CustomerID": "id", "Country": "text", "Category": "text",
}


# --------------------------------------------------------------------------
# Small reusable helpers (also imported by transformation.py)
# --------------------------------------------------------------------------
def missing_mask(series: pd.Series) -> pd.Series:
    """True where a value is null OR an empty/blank string."""
    mask = series.isna()
    if not (pd.api.types.is_numeric_dtype(series) or pd.api.types.is_datetime64_any_dtype(series)):
        blank = series.astype("string").str.strip().eq("").fillna(False).astype(bool)
        mask = mask | blank
    return mask.astype(bool)


def cancelled_mask(invoice: pd.Series) -> pd.Series:
    """True for invoices whose number starts with 'C' (cancellations / returns)."""
    inv = invoice.astype("string").str.strip().str.upper()
    return inv.str.startswith("C").fillna(False).astype(bool)


def non_product_mask(stock: pd.Series) -> pd.Series:
    """True for postage / bank charges / manual adjustments / gift vouchers."""
    s = stock.astype("string").str.strip().str.upper()
    exact = s.isin(list(NON_PRODUCT_CODES)).astype(bool)
    gift = s.str.startswith("GIFT_").fillna(False).astype(bool)
    return (exact | gift).astype(bool)


def _pct(count: int, total: int) -> float:
    return round(count / total * 100, 2) if total else 0.0


def _grade(score: float) -> str:
    if score >= 90:
        return "Excellent"
    if score >= 75:
        return "Good"
    if score >= 50:
        return "Fair"
    return "Poor"


# --------------------------------------------------------------------------
# Individual checks
# --------------------------------------------------------------------------
def _check_missing(df: pd.DataFrame) -> tuple[list[dict], int]:
    """Missing values for every column in the uploaded file."""
    rows = len(df)
    table, total_missing = [], 0
    for col in df.columns:
        n = int(missing_mask(df[col]).sum())
        total_missing += n
        table.append({"Column": str(col), "Missing": n, "Missing %": _pct(n, rows)})
    table.sort(key=lambda r: r["Missing"], reverse=True)
    return table, total_missing


def _check_invalid(mapped: pd.DataFrame) -> tuple[list[dict], pd.Series]:
    """
    Detect invalid values. Returns (list of check results, boolean mask of rows
    that have at least one problem that counts toward the score).
    """
    rows = len(mapped)
    checks: list[dict] = []
    union = pd.Series(False, index=mapped.index)

    def add(name: str, mask: pd.Series, severity: str, counts: bool = True) -> None:
        nonlocal union
        mask = mask.fillna(False).astype(bool)
        checks.append({"Check": name, "Count": int(mask.sum()),
                       "Pct": _pct(int(mask.sum()), rows), "Severity": severity})
        if counts:
            union = union | mask

    cancelled = None
    if "InvoiceNo" in mapped:
        cancelled = cancelled_mask(mapped["InvoiceNo"])

    qty = None
    if "Quantity" in mapped:
        qty = pd.to_numeric(mapped["Quantity"], errors="coerce")
        present = ~missing_mask(mapped["Quantity"])
        add("Quantity is not a number", qty.isna() & present, "error")
        add("Quantity equals zero", qty == 0, "error")
        if cancelled is not None:
            add("Negative quantity on a non-cancelled invoice", (qty < 0) & ~cancelled, "error")
            add("Cancelled invoice (C...) with positive quantity", (qty > 0) & cancelled, "error")

    if "UnitPrice" in mapped:
        price = pd.to_numeric(mapped["UnitPrice"], errors="coerce")
        present = ~missing_mask(mapped["UnitPrice"])
        add("Unit price is not a number", price.isna() & present, "error")
        add("Unit price is negative", price < 0, "error")
        add("Unit price is zero", price == 0, "warning")

    if "InvoiceDate" in mapped:
        dates = parse_dates(mapped["InvoiceDate"])
        present = ~missing_mask(mapped["InvoiceDate"])
        add("Invoice date cannot be parsed", dates.isna() & present, "error")
        try:
            future = dates > (pd.Timestamp.now() + pd.Timedelta(days=1))
        except TypeError:  # timezone-aware dates: skip this check
            future = pd.Series(False, index=mapped.index)
        add("Invoice date is in the future", future, "warning")

    if "StockCode" in mapped:
        add("Non-product stock code (postage, fees, adjustments)",
            non_product_mask(mapped["StockCode"]), "warning")

    if cancelled is not None:  # informational only - NOT an error, it is valid business data
        add("Cancelled invoices (returns) - informational", cancelled, "info", counts=False)

    return checks, union


def _check_types(mapped: pd.DataFrame) -> list[dict]:
    """Compare the stored data type of each column with the type it should have."""
    out = []
    for col in mapped.columns:
        series = mapped[col]
        expected = EXPECTED_TYPES.get(col, "text")
        actual = str(series.dtype)
        non_null = series[~missing_mask(series)]
        convertible = 100.0

        if expected == "numeric":
            if pd.api.types.is_numeric_dtype(series):
                status = "Correct"
            else:
                ok = pd.to_numeric(non_null, errors="coerce").notna().sum()
                convertible = _pct(int(ok), len(non_null)) if len(non_null) else 100.0
                status = "Needs conversion" if convertible == 100.0 else "Mixed values"
        elif expected == "datetime":
            if pd.api.types.is_datetime64_any_dtype(series):
                status = "Correct"
            else:
                ok = parse_dates(non_null).notna().sum()
                convertible = _pct(int(ok), len(non_null)) if len(non_null) else 100.0
                status = "Needs conversion" if convertible == 100.0 else "Mixed values"
        elif expected == "id":  # IDs should be text, not 17850.0
            status = "Correct" if not pd.api.types.is_float_dtype(series) else "Needs conversion"
        else:  # text
            status = "Correct" if not pd.api.types.is_numeric_dtype(series) else "Needs conversion"

        out.append({"Column": col, "Expected": expected, "Actual": actual,
                    "Convertible %": convertible, "Status": status})
    return out


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------
def run_quality_checks(df: pd.DataFrame) -> dict:
    """Run every check and return the quality report (JSON-friendly dict)."""
    if df is None or not isinstance(df, pd.DataFrame):
        raise ValueError("A pandas DataFrame is required.")
    if df.empty:
        raise ValueError("The dataset is empty - nothing to check.")

    rows, cols = df.shape
    mapped, mapping, missing_required = map_columns(df)

    missing_table, total_missing = _check_missing(df)
    dup_count = int(df.duplicated().sum())
    invalid_checks, invalid_union = _check_invalid(mapped)
    type_table = _check_types(mapped)

    # ---- scoring --------------------------------------------------------
    total_cells = rows * cols
    completeness = 100 - _pct(total_missing, total_cells)
    uniqueness = 100 - _pct(dup_count, rows)
    validity = 100 - _pct(int(invalid_union.sum()), rows)
    weights = {"Correct": 1.0, "Needs conversion": 0.5, "Mixed values": 0.0}
    type_score = (100 * np.mean([weights[t["Status"]] for t in type_table])) if type_table else 0.0

    dims = {
        "Completeness": round(float(completeness), 1),
        "Uniqueness": round(float(uniqueness), 1),
        "Validity": round(float(validity), 1),
        "Type consistency": round(float(type_score), 1),
    }
    score = round(sum(dims[k] * w for k, w in SCORE_WEIGHTS.items()), 1)

    # ---- recommendations -----------------------------------------------
    recs: list[str] = []
    if missing_required:
        recs.append("Required columns not found: " + ", ".join(missing_required)
                    + ". Rename your columns or add them - the ETL pipeline cannot run without them.")
    for m in missing_table[:3]:
        if m["Missing"] > 0:
            recs.append(f"'{m['Column']}' has {m['Missing']:,} missing values ({m['Missing %']}%).")
    if dup_count:
        recs.append(f"{dup_count:,} exact duplicate rows will be removed by the ETL step.")
    for c in invalid_checks:
        if c["Severity"] != "info" and c["Count"] > 0:
            recs.append(f"{c['Count']:,} rows: {c['Check'].lower()}.")
    for t in type_table:
        if t["Status"] != "Correct":
            recs.append(f"Column '{t['Column']}' is stored as {t['Actual']} but should be "
                        f"{t['Expected']} ({t['Status'].lower()}).")
    if not recs:
        recs.append("No issues found - the dataset looks clean.")

    return {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "rows": int(rows),
        "columns": int(cols),
        "column_mapping": mapping,
        "unmapped_columns": [str(c) for c in df.columns if str(c) not in mapping],
        "missing_required": missing_required,
        "ready_for_etl": not missing_required,
        "missing_values": missing_table,
        "total_missing_cells": int(total_missing),
        "duplicates": {"count": dup_count, "pct": _pct(dup_count, rows)},
        "invalid_checks": invalid_checks,
        "invalid_rows": int(invalid_union.sum()),
        "data_types": type_table,
        "dimension_scores": dims,
        "score": score,
        "grade": _grade(score),
        "recommendations": recs,
    }


# --------------------------------------------------------------------------
# Report exports
# --------------------------------------------------------------------------
def issues_table(report: dict) -> pd.DataFrame:
    """Flat table of every finding (used for CSV export and on-screen display)."""
    rows = []
    for m in report["missing_values"]:
        rows.append({"Type": "Missing values", "Item": m["Column"],
                     "Count": m["Missing"], "Percent": m["Missing %"]})
    rows.append({"Type": "Duplicates", "Item": "Exact duplicate rows",
                 "Count": report["duplicates"]["count"], "Percent": report["duplicates"]["pct"]})
    for c in report["invalid_checks"]:
        rows.append({"Type": f"Invalid values ({c['Severity']})", "Item": c["Check"],
                     "Count": c["Count"], "Percent": c["Pct"]})
    for t in report["data_types"]:
        rows.append({"Type": "Data type", "Item": f"{t['Column']}: {t['Actual']} -> {t['Expected']}",
                     "Count": 0, "Percent": 100 - t["Convertible %"] if t["Status"] == "Mixed values" else 0.0})
    return pd.DataFrame(rows)


def report_to_json(report: dict) -> bytes:
    return json.dumps(report, indent=2, default=str).encode("utf-8")


def report_to_csv(report: dict) -> bytes:
    return issues_table(report).to_csv(index=False).encode("utf-8")


def report_to_markdown(report: dict) -> bytes:
    """Human-readable report suitable for sharing or printing."""
    L: list[str] = []
    L.append("# DataPulse - Data Quality Report")
    L.append(f"_Generated: {report['generated_at']}_\n")
    L.append(f"**Overall score: {report['score']} / 100 ({report['grade']})**\n")
    L.append(f"- Rows: {report['rows']:,}\n- Columns: {report['columns']}")
    L.append(f"- Total missing cells: {report['total_missing_cells']:,}")
    L.append(f"- Duplicate rows: {report['duplicates']['count']:,} ({report['duplicates']['pct']}%)")
    L.append(f"- Rows with invalid values: {report['invalid_rows']:,}\n")

    L.append("## Score breakdown")
    L.append("| Dimension | Score | Weight |\n|---|---|---|")
    for k, v in report["dimension_scores"].items():
        L.append(f"| {k} | {v} | {int(SCORE_WEIGHTS[k] * 100)}% |")

    L.append("\n## Missing values")
    L.append("| Column | Missing | Missing % |\n|---|---|---|")
    for m in report["missing_values"]:
        L.append(f"| {m['Column']} | {m['Missing']:,} | {m['Missing %']} |")

    L.append("\n## Invalid values")
    L.append("| Check | Rows | % | Severity |\n|---|---|---|---|")
    for c in report["invalid_checks"]:
        L.append(f"| {c['Check']} | {c['Count']:,} | {c['Pct']} | {c['Severity']} |")

    L.append("\n## Data types")
    L.append("| Column | Expected | Actual | Status |\n|---|---|---|---|")
    for t in report["data_types"]:
        L.append(f"| {t['Column']} | {t['Expected']} | {t['Actual']} | {t['Status']} |")

    L.append("\n## Recommendations")
    L.extend(f"- {r}" for r in report["recommendations"])
    return ("\n".join(L) + "\n").encode("utf-8")
