"""
Pipeline Monitoring module.

Two jobs:
  1. run_pipeline()  - orchestrates the whole ETL flow stage by stage
        Extract -> Quality check -> Transform -> Load raw -> Load clean -> Export files
     and measures how long each stage takes.
  2. Execution history - every run is saved in the `pipeline_runs` SQLite table with its
     status (RUNNING / SUCCESS / FAILED), record counts, quality score and details, so the
     dashboard can show processing summaries and trends.

This module has NO Streamlit code.
"""
from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Callable

import pandas as pd

from modules import database as db
from modules.data_quality import run_quality_checks
from modules.ingestion import map_columns
from modules.transformation import clean_dataset

PROCESSED_DIR = db.BASE_DIR / "data" / "processed"
CLEAN_EXPORT_NAME = "clean_retail_data.csv"
REJECTED_EXPORT_NAME = "rejected_records.csv"

STATUS_RUNNING, STATUS_SUCCESS, STATUS_FAILED = "RUNNING", "SUCCESS", "FAILED"

_RUNS_DDL = f"""
CREATE TABLE IF NOT EXISTS {db.TABLE_RUNS} (
    run_id             INTEGER PRIMARY KEY AUTOINCREMENT,
    source_file        TEXT,
    status             TEXT NOT NULL,
    started_at         TEXT NOT NULL,
    finished_at        TEXT,
    duration_sec       REAL,
    rows_input         INTEGER,
    rows_clean         INTEGER,
    rows_rejected      INTEGER,
    duplicates_removed INTEGER,
    quality_score      REAL,
    error_message      TEXT,
    details_json       TEXT
)
"""

ProgressCallback = Callable[[float, str], None]


class PipelineError(Exception):
    """A pipeline stage failed in a way the user should be told about."""


# --------------------------------------------------------------------------
# Run history (SQLite)
# --------------------------------------------------------------------------
def init_runs_table(conn: sqlite3.Connection) -> None:
    conn.execute(_RUNS_DDL)
    conn.commit()


def start_run(conn: sqlite3.Connection, source_file: str, rows_input: int) -> int:
    init_runs_table(conn)
    cur = conn.execute(
        f"INSERT INTO {db.TABLE_RUNS} (source_file, status, started_at, rows_input) VALUES (?,?,?,?)",
        (source_file, STATUS_RUNNING, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), int(rows_input)))
    conn.commit()
    return int(cur.lastrowid)


def finish_run(conn: sqlite3.Connection, run_id: int, summary: dict) -> None:
    conn.execute(
        f"""UPDATE {db.TABLE_RUNS} SET status=?, finished_at=?, duration_sec=?, rows_input=?,
            rows_clean=?, rows_rejected=?, duplicates_removed=?, quality_score=?,
            error_message=?, details_json=? WHERE run_id=?""",
        (summary["status"], summary["finished_at"], summary["duration_sec"], summary["rows_input"],
         summary["rows_clean"], summary["rows_rejected"], summary["duplicates_removed"],
         summary["quality_score"], summary.get("error"),
         json.dumps(summary.get("details", {}), default=str), run_id))
    conn.commit()


def get_run_history(limit: int = 50, db_path: Path | str | None = None) -> pd.DataFrame:
    """Most recent runs first. Returns an empty DataFrame if nothing has run yet."""
    cols = ["run_id", "source_file", "status", "started_at", "finished_at", "duration_sec",
            "rows_input", "rows_clean", "rows_rejected", "duplicates_removed", "quality_score",
            "error_message"]
    path = Path(db_path) if db_path else db.DB_PATH
    if not path.exists():
        return pd.DataFrame(columns=cols)
    with db.readonly(path) as conn:
        if not db.table_exists(conn, db.TABLE_RUNS):
            return pd.DataFrame(columns=cols)
        return pd.read_sql_query(
            f"SELECT {', '.join(cols)} FROM {db.TABLE_RUNS} ORDER BY run_id DESC LIMIT ?",
            conn, params=(int(limit),))


def get_run_details(run_id: int, db_path: Path | str | None = None) -> dict | None:
    """One run including its parsed details (stages, rejection reasons, quality report)."""
    path = Path(db_path) if db_path else db.DB_PATH
    if not path.exists():
        return None
    with db.readonly(path) as conn:
        if not db.table_exists(conn, db.TABLE_RUNS):
            return None
        cur = conn.execute(f"SELECT * FROM {db.TABLE_RUNS} WHERE run_id=?", (int(run_id),))
        row = cur.fetchone()
        if row is None:
            return None
        record = dict(zip([d[0] for d in cur.description], row))
    try:
        record["details"] = json.loads(record.pop("details_json") or "{}")
    except json.JSONDecodeError:
        record["details"] = {}
    return record


def get_latest_run(status: str | None = None, db_path: Path | str | None = None) -> dict | None:
    history = get_run_history(limit=200, db_path=db_path)
    if status:
        history = history[history["status"] == status]
    if history.empty:
        return None
    return get_run_details(int(history.iloc[0]["run_id"]), db_path)


def get_latest_successful_run_id(db_path: Path | str | None = None) -> int:
    """Used by the UI as a cache key: changes whenever new data is loaded. 0 = none yet."""
    history = get_run_history(limit=200, db_path=db_path)
    ok = history[history["status"] == STATUS_SUCCESS]
    return int(ok.iloc[0]["run_id"]) if not ok.empty else 0


def get_latest_quality_report(db_path: Path | str | None = None) -> dict | None:
    run = get_latest_run(STATUS_SUCCESS, db_path)
    return (run or {}).get("details", {}).get("quality_report")


def clear_run_history(db_path: Path | str | None = None) -> None:
    path = Path(db_path) if db_path else db.DB_PATH
    if not path.exists():
        return
    conn = db.get_connection(path)
    try:
        conn.execute(f"DROP TABLE IF EXISTS {db.TABLE_RUNS}")
        conn.commit()
    finally:
        conn.close()


# --------------------------------------------------------------------------
# The pipeline
# --------------------------------------------------------------------------
def run_pipeline(df_raw: pd.DataFrame, source_name: str,
                 db_path: Path | str | None = None,
                 processed_dir: Path | str | None = None,
                 progress_callback: ProgressCallback | None = None) -> dict:
    """
    Run Extract -> Quality -> Transform -> Load and record the run.

    Never raises for expected problems: the returned summary has status
    "SUCCESS" or "FAILED" (with an `error` message) and a `stages` list.
    """
    processed = Path(processed_dir) if processed_dir else PROCESSED_DIR
    stages: list[dict] = []
    t_start = time.perf_counter()
    started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_stages = 6
    state: dict = {}

    def notify(done: int, message: str) -> None:
        if progress_callback:
            try:
                progress_callback(done / total_stages, message)
            except Exception:  # a UI problem must never break the pipeline
                pass

    def run_stage(index: int, name: str, func: Callable[[], str]) -> None:
        notify(index, f"{name}...")
        t0 = time.perf_counter()
        try:
            detail = func()
        except Exception as exc:
            stages.append({"Stage": name, "Status": "Failed",
                           "Seconds": round(time.perf_counter() - t0, 2), "Detail": str(exc)})
            raise
        stages.append({"Stage": name, "Status": "Success",
                       "Seconds": round(time.perf_counter() - t0, 2), "Detail": detail})
        notify(index + 1, f"{name} complete")

    summary: dict = {
        "run_id": None, "status": STATUS_FAILED, "source_file": source_name, "started_at": started_at,
        "finished_at": None, "duration_sec": 0.0, "rows_input": 0 if df_raw is None else int(len(df_raw)),
        "rows_clean": 0, "rows_rejected": 0, "duplicates_removed": 0, "quality_score": None,
        "quality_grade": None, "rejection_reasons": {}, "stages": stages, "steps": [], "error": None,
    }

    try:
        conn = db.get_connection(db_path)
    except db.DatabaseError as exc:
        summary["error"] = str(exc)
        return summary

    try:
        summary["run_id"] = start_run(conn, source_name, summary["rows_input"])

        # ---- 1. Extract -------------------------------------------------------
        def extract() -> str:
            if df_raw is None or df_raw.empty:
                raise PipelineError("No dataset is loaded. Upload a file first.")
            _, mapping, missing = map_columns(df_raw)
            if missing:
                raise PipelineError("Required column(s) missing: " + ", ".join(missing))
            return f"{len(df_raw):,} rows, {len(mapping)} recognised columns"

        run_stage(0, "Extract", extract)

        # ---- 2. Quality check --------------------------------------------------
        def quality() -> str:
            state["report"] = run_quality_checks(df_raw)
            r = state["report"]
            return f"Score {r['score']}/100 ({r['grade']})"

        run_stage(1, "Quality check", quality)

        # ---- 3. Transform ------------------------------------------------------
        def transform() -> str:
            state["result"] = clean_dataset(df_raw)
            s = state["result"].stats
            return f"{s['rows_clean']:,} clean, {s['rows_rejected']:,} rejected"

        run_stage(2, "Transform", transform)

        # ---- 4. Load raw ---------------------------------------------------------
        run_stage(3, "Load raw data",
                  lambda: f"{db.save_raw(df_raw, conn):,} rows -> {db.TABLE_RAW}")

        # ---- 5. Load clean + rejected -----------------------------------------------
        def load_clean() -> str:
            res = state["result"]
            n_clean = db.save_clean(res.clean, conn)
            n_rej = db.save_rejected(res.rejected, conn)
            return f"{n_clean:,} rows -> {db.TABLE_CLEAN}, {n_rej:,} rows -> {db.TABLE_REJECTED}"

        run_stage(4, "Load clean data", load_clean)

        # ---- 6. Export files ---------------------------------------------------------
        def export() -> str:
            res = state["result"]
            try:
                processed.mkdir(parents=True, exist_ok=True)
                res.clean.to_csv(processed / CLEAN_EXPORT_NAME, index=False)
                res.rejected.to_csv(processed / REJECTED_EXPORT_NAME, index=False)
            except OSError as exc:  # e.g. read-only hosting; the database copy is still fine
                return f"Skipped file export ({exc})"
            return f"Saved {CLEAN_EXPORT_NAME} and {REJECTED_EXPORT_NAME}"

        run_stage(5, "Export files", export)

        stats, report = state["result"].stats, state["report"]
        summary.update(
            status=STATUS_SUCCESS, rows_clean=stats["rows_clean"], rows_rejected=stats["rows_rejected"],
            duplicates_removed=stats["duplicates_removed"], quality_score=report["score"],
            quality_grade=report["grade"], rejection_reasons=stats["rejection_reasons"],
            steps=state["result"].steps, stats=stats)

    except Exception as exc:
        summary["status"] = STATUS_FAILED
        summary["error"] = str(exc) or exc.__class__.__name__
        if "report" in state:
            summary["quality_score"] = state["report"]["score"]
            summary["quality_grade"] = state["report"]["grade"]
    finally:
        summary["finished_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        summary["duration_sec"] = round(time.perf_counter() - t_start, 2)
        summary["details"] = {
            "stages": stages, "steps": summary["steps"], "rejection_reasons": summary["rejection_reasons"],
            "stats": summary.get("stats", {}), "quality_grade": summary["quality_grade"],
            "quality_report": state.get("report"),
        }
        try:
            if summary["run_id"] is not None:
                finish_run(conn, summary["run_id"], summary)
        except sqlite3.Error as exc:
            summary["error"] = (summary["error"] or "") + f" (could not save run history: {exc})"
        finally:
            conn.close()

    notify(total_stages, "Pipeline " + summary["status"].lower())
    return summary
